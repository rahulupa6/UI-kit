﻿import {Component, Injectable } from 'angular2/core';
import {RouteConfig, IPolicyHeaders, ROUTER_DIRECTIVES, Router } from 'angular2/router';

import { PolicyDetails,PolicyDetailsService,drivers,vehicles } from '../service/policy-details.service';
import { Policy,PolicyService} from 'app/policy/service/policy.service';

@Component({
    selector: 'policy-list',
    templateUrl: 'app/policy-details/view/policy-details.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers :[PolicyDetailsService,PolicyService]
})



export class PolicyDetailsComponent implements OnDestroy, OnInit {
    policyDetails: PolicyDetails;
	policy: Policy[];
	policyHeaders:PolicyHeaders;
	
    	
    constructor(private _policyDetailsService: PolicyDetailsService,
				private _policyService: PolicyService,
				private _router: Router) {  

				
    }
    
	back(){
			this._router.navigate(['Home']);
	}
gotoPayment(polnumber:string)
	{
		console.log(polnumber);
		sessionStorage.setItem("polNo",polnumber);
		this._router.navigate(['MakePayment']);
	}
	
	getHeader() {
	 this.policyHeaders={};
	 this._policyDetailsService.getPolicyHeaderDetails()
	                    .subscribe(policyHeaders =>
						  if(policyHeaders != undefined)
						  {
																	

					             this.assignPolicyHeaders(policyHeaders);
								//this.policyHeaders.PolicyHeaderData = policyHeaders;
						  }
					); 
					
	}
	getPolicyDetails() {
        this.policyDetails = {};
		this.policyDetails.vehicles=[];
		console.log('policy details log')
		this._policyDetailsService.getPolicyDetails()
					.subscribe(policyDetails => {
							if(policyDetails != undefined)
							{
								//console.log("policyDetails-"+JSON.stringify(policyDetails));	
								console.log(policyDetails);
								this.policyDetails = policyDetails;
								sessionStorage.setItem('PolicyDetails',JSON.stringify(this.policyDetails));
								console.log(this.policyDetails.vehicles);

							}
					});
    }
	getPolicy() {
        this.policy = [];
			
		this._policyService.getPolicy()
					.subscribe(policy => {
								this.policy = policy;
					});
    }
	getDetails(details) {
        //console.log("asdasd");
		alert(details);
		   this.getPolicy(15);
    }
	assignPolicyHeaders(res:any)
	{
	  console.log(res);
		this.policyHeaders.module=res.FieldName1;
	this.policyHeaders.startDate=res.FieldName5;
	this.policyHeaders.endDate=res.FieldName6;
	this.policyHeaders.status=res.FieldName8;
  this.policyHeaders.nextPaymentDue=res.FieldName2;
  this.policyHeaders.nextPaymentDueIcon=res.FieldName2IconPath;
  this.policyHeaders.downloadReciepts=res.FieldName3;
  this.policyHeaders.downloadRecieptsIcon=res.FieldName3IconPath;
  this.policyHeaders.downloadPolicy=res.FieldName4;
  this.policyHeaders.downloadPolicyIcon=res.FieldName4IconPath;
  this.policyHeaders.agent=res.FieldName7;
  this.policyHeaders.vehicle1=res.FieldName9;
  this.policyHeaders.vehicle2=res.FieldName10;
 this.policyHeaders.Payment=res.FieldName11;
  this.policyHeaders.paymentIcon=res.FieldName11IconPath;
  console.log('policy header done');
	 
	}

    ngOnDestroy() {
    }

    ngOnInit() {
			console.log('Ploicy load')
			this.policyHeaders={};

       // this.getPolicyDetails();
        // this.policyHeaders ={};
        //this.policyHeaders.PolicyHeaderData={};
      /*  this._policyDetailsService.getPolicyDetailHeaders("Policy-Details")
					.subscribe(policyHeaders => {
					             this.assignPolicyHeaders(policyHeaders);
								//this.policyHeaders.PolicyHeaderData = policyHeaders;
					}); */
		
		
		this.getHeader();
		this.getPolicyDetails();

    }

}