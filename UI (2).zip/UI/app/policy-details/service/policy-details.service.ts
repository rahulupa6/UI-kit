﻿import { Injectable } from 'angular2/core';
import { Http, Response,RequestOptions,Headers } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';

//let policyDetailsUrl = 'api/policy-data.json';

  let policyHeaderDetailsUrl = CONFIG.baseUrls.policyHeaderUrl;
  let policyDetailsUrl = CONFIG.baseUrls.policyDataUrl;


export interface PolicyDetails {
  policyNumber: string;
  startDate: string;
  endDate:String;
  status:String;
  userId:string;
  nextPaymentDue: string;
  payment: string;
  remindMe: string;
  paymentDue:string;
  drivers:drivers[];
  vehicles:vehicles[];
  
}

export interface drivers{

_id:string;
firstname:string;
dateofBirth:string;
maritalStatus:string;
gender:string;
drivingLicenseNumber:string;
ssn:string;
}

export interface vehicles{

_id:string;
year:string;
maker:string;
model:string;
subModel:string;
vehicleIdentityNumber:string;
accident:string;
}

export interface PolicyHeaders {
 module: String;
  startDate: string;
  endDate:String;
  status:String;
  nextPaymentDue: string;
  nextPaymentDueIcon:string;
  downloadReciepts:string;
  downloadRecieptsIcon:string;
  downloadPolicy:string;
  downloadPolicyIcon:string;
  agent:string;
  vehicle1:string;
  vehicle2:string;
  Payment: string;
  paymentIcon:string;

 // remindMe: string;
}

/*export interface PolicyHeaders {
  PolicyHEADERS: IPolicyHeader;
}*/



@Injectable()
export class PolicyDetailsService {
  constructor(private _http: Http) {
      
  }

  getPolicyDetails() {
      
	 /*  return this._http.get(policyDetailsUrl)
      .map((response: Response) => <PolicyDetails[]>response.json().data)
      .catch(this.handleError)
      .finally();*/

	  //uncomment below code for details
		/* let headers = new Headers();
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  

			let body = '{"userId":"'+sessionStorage.getItem("userId")+'"}';
			//let body = '{"userId":"VR5032386"}';
			console.log('body' + body);
					


	    return this._http
            .post(policyDetailsUrl, body,{headers : headers})
            .map((response: Response) => response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();*/ 

			console.log('policy details service');
			return this._http
            .get('api/policy-data.json')
            .map((response: Response) => response.json())
			.do(d=>console.log('d'+d))
            .catch(this.handleError)
            .finally();

  }

  getPolicyHeaderDetails(){
  console.log(policyHeaderDetailsUrl)
   return this._http.get(policyHeaderDetailsUrl)
      .map((response: Response) =>response.json())
	     .do(d=>console.log("pol serv-"+d))
      .catch(this.handleError)
      .finally();

  }
  
  getPolicyDetailHeaders(ModuleName: number) {
     return this.getPolicyHeaderDetails()
      .map(polices => polices.find(p => p.module == ModuleName));

	  console.log("sdfsddddddd"+policyNumber);
  }

 
}