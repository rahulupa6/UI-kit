﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import { CONFIG } from 'common/config.ts';

let MenuUrl=CONFIG.baseUrls.MenusUrl;
let BannerUrl=CONFIG.baseUrls.BannersUrl; 

export interface IMenuLabel
{
 MyPolicies:string;
BillsPayments:string;
Claims:string;
TransactionHistory:string;
Documents:string;
NewOffers:string;
Search:string;
ImgIcon:string;

}

export interface IBannerLabel
{
 BannerImage:string;
BannerImageIcon:string;
ProfileComplete:string;
PendingPayments:string;
PendingPaymentsIcon:string;
SavedQuotes:string;
SavedQuotesIcon:string;
LiveChat:string;
CallMe:string;
}

export interface IHome
{
 MenuLabel:IMenuLabel;
 BannerLabel:IBannerLabel;
}




@Injectable()
export class HomeService {
  constructor(private _http: Http
  ) {
      console.log('Home load');
  }

  getMenuLabel() {
      console.log(MenuUrl);

    return this._http.get(MenuUrl)
      .map((response: Response) => <IMenuLabel>response.json())
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }
  getBannerLabel() {
      console.log(BannerUrl);

    return this._http.get(BannerUrl)
      .map((response: Response) => <IBannerLabel>response.json())
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }
 /* getRegisterData() {
    //console.log()
	return this._http.get(RegUrl)
	  .map((response:Response)=><IRegisterControl>response.json().RegData)
	   .do(data=>console.log(data))
	   .catch(this.handleError)
	   .finally();
  
  }
  submitDataService(RegisterControl:IRegisterControl) {
  console.log(RegisterControl);

  }*/


    

 
}

