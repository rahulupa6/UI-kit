import {Component, Injectable,ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';
import {PolicyDetailsComponent} from 'app/policy-details/component/policy-details.component';

import {HorizontalMenuComponent} from 'app/personalize/horizontal-menu/component/horizontal-menu.component';

import {IMenuLabel,IBannerLabel,IHome,HomeService} from '../service/home.service'

//import { PolicyDetails,PolicyDetailsService } from 'app/policy-details/service/policy-details.service';

import {CallBackComponent} from 'app/call-back/component/call-back.component';

import {ChatUsComponent} from 'app/chat-us/component/chat-us.component';

import {NewOffersComponent} from 'app/new-offers/component/new-offers.component';

@Component({
    selector: 'router-outlet',
    templateUrl: 'app/home/view/home.component.html',
    directives: [ROUTER_DIRECTIVES,PolicyDetailsComponent,HorizontalMenuComponent,CallBackComponent,ChatUsComponent],
	providers:[HomeService]
	
})


export class HomeComponent implements OnInit()
{
 
	//@ViewChild(PolicyDetailsComponent) policyDetailsComponent:PolicyDetailsComponent;
 	
	home:IHome;
		//policyHeaders:PolicyHeaders;

	constructor(private _homeService:HomeService,private _router:Router
				)
	{
	  console.log('home load');
	}
	getMenuLabels()
	{
	  
	 

	  //console.log('comp -'+this.register.RegisterLabel);

	   this._homeService.getMenuLabel()
	           .subscribe(home => {
			   if(home != undefined)
			   {
			           this.assignMenuLabel(home);
				}
				   //this.register.RegisterLabel= register;
				   //console.log('comp-'+this.home.RegisterLabel);
				});
				
	}
	assignMenuLabel(menu:any)
	{
	   this.home.MenuLabel.MyPolicies=menu.FieldName1;
	   this.home.MenuLabel.BillsPayments=menu.FieldName2;
	   this.home.MenuLabel.Claims=menu.FieldName3;
	   this.home.MenuLabel.TransactionHistory=menu.FieldName4;
	   this.home.MenuLabel.Documents=menu.FieldName5;
	   this.home.MenuLabel.NewOffers=menu.FieldName6;
	   this.home.MenuLabel.Search=menu.FieldName7;
	   this.home.MenuLabel.BannerImageIcon=menu.FieldName7IconPath;

	   console.log('menu done');
	}
	getBannerLabels()
	{
	  

	  //console.log('comp -'+this.register.RegisterLabel);

	   this._homeService.getBannerLabel()
	           .subscribe(home => {
				        this.assignBannerLabel(home);
				   //this.register.RegisterControl= register;
				  
				});
				
	}

	assignBannerLabel(banner:any)
	{
	   this.home.BannerLabel.BannerImage=banner.FieldName1;
	   this.home.BannerLabel.BannerImageIcon=banner.FieldName1IconPath;
	   this.home.BannerLabel.ProfileComplete=banner.FieldName2;
	   this.home.BannerLabel.PendingPayments=banner.FieldName3;
	   this.home.BannerLabel.PendingPaymentsIcon=banner.FieldName3IconPath;
	   this.home.BannerLabel.SavedQuotes=banner.FieldName4;
	   this.home.BannerLabel.SavedQuotesIcon=banner.FieldName4IconPath;
	   this.home.BannerLabel.LiveChat=banner.FieldName5;
	   this.home.BannerLabel.CallMe=banner.FieldName6;
	    console.log('banner done');
	}
	

	/*submitData()
	{
	  console.log('com11-'+this.register.RegisterControl);
       this._registerService.submitDataService(this.register.RegisterControl); 
	    this._router.navigate(['Login']);\\added
	}*/
	

	getHeader() {
	 this.policyHeaders={};
	 this._policyService.getPolicyHeaderDetails()
	                    .subscribe(policyHeaders =>
									console.log(policyHeaders);
					             //this.policyDetailsComponent.assignPolicyHeaders(policyHeaders);
					); 
	}

	 ngOnInit() {
	 this.home={};
	  this.home.MenuLabel={};
	  this.home.BannerLabel={};
        this.getMenuLabels();
		this.getBannerLabels();


		//this.getHeader();
		
    }

}