﻿import { Injectable } from 'angular2/core';
import { Http, Response,RequestOptions,Headers } from 'angular2/http';
import { Observable } from 'rxjs/Rx';


import { URLS } from 'common/common';

//let serviceUrl = 'https://microsoft-apiapp99e68ccbbddb4dc889decc31fe8783d0.azurewebsites.net/api/translate';
let serviceUrl = 'http://digitalportalbot.azurewebsites.net/api/translate';

@Injectable()
export class ChatUsService {
  constructor(private _http: Http
  ) {
      console.log('chat loaded');
  }
  

  postChat(message:string,lang:string){
    
  /*let body='Type=Message&Text='+message*/;


 /* body='{"Type":"Message","Text":"'+message+'"}';  
 console.log('post loaded:'+body);  

    return this._http.post(this.serviceUrl, body)	
                    .do(d=>console.log(d))
					.toPromise()
             .then(this.extractData)
             .catch(this.handleError);*/


//avadhut added


let headers = new Headers({ "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" });
let options = new RequestOptions({ headers: headers });

			//let body='{"Type":"Message","Text":"'+message+'"}';  
			
		let body='Type=Message&Language='+lang+'&Text='+message;
		
		console.log(body);

        return this._http
            .post(serviceUrl, body,options)
            .map((response: Response) => response.json())
			.do(d=>console.log("Response"+JSON.stringify(d)))
            .catch(this.handleError)
            .finally();


}

/*private extractData(res: Response) {
  let body = res.json();
 console.log(body);
}*/
            
  
  
  
  

 
}