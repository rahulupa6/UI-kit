import{Component} from 'angular2/core';
import { ROUTER_DIRECTIVES,Router} from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';
import { ChatUsService } from '../service/chat-us.service';


@Component({

selector:'chat-us',
templateUrl:'app/chat-us/view/chat-us.component.html',
directives: [ ROUTER_DIRECTIVES],
providers :[ChatUsService],
styles : [`
#wrapper {
    margin:0 auto;
    padding-bottom:25px;
    background:#EBF4FB;
    width:504px;
    border:1px solid #ACD8F0; }
  
#chatbox {
    text-align:left;
    margin:0 auto;
    margin-bottom:25px;
    padding:10px;
    background:#fff;
    height:270px;
    width:430px;
    border:1px solid #ACD8F0;
    overflow:auto; }

`]


})
export class ChatUsComponent implements OnDestroy, OnInit{

message:string="";
conversation:string="";
chatUs:boolean=true;
isEnglish:boolean=true;

lang:string="";
constructor(private _chatService: ChatUsService,
				private _router: Router) {  
    }

	send()
	{
		if(!this.isEnglish)
		{
		  this.lang="fr";
		}
		else
		 this.lang="en";
		//this.conversation+="<p style='float:left;background-color:#F0F0F0'>"+sessionStorage.getItem("userName")+" : "+this.message+"</p>";
		this.conversation+='<div class="bubble"> <span class="personName">'+sessionStorage.getItem("userName")+': </span> <br><span class="personSay">'+this.message+'</span> </div>';
 
		
		this._chatService.postChat(this.message,this.lang)
		.subscribe(reply=>
			//this.conversation+="<p style='float:right;background-color:#d37302'> Jarvis :"+reply.text+"</p>";
			this.conversation+='<div class="bubble2"> <span class="personName2">Jarvis :</span> <br> <span class="personSay2">'+reply.text+'</span> </div>';
			
			this.message="";
		);

		
	
	}
	ngOnDestroy() {
    }

    ngOnInit()
	 {
	   this.chatUs=true;
		//this.conversation+='<div class="bubble"> <span class="personName">'+sessionStorage.getItem("userName")+': </span> <br><span class="personSay">'+this.message+'</span> </div>';
		this.conversation+='<div class="bubble2"> <span class="personName2">Jarvis :</span> <br> <span class="personSay2"> Hello '+sessionStorage.getItem("userName")+', How may I assist you today?</span> </div>';
 
        
    }

}