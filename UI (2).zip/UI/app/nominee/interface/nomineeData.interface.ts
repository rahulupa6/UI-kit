export interface NomineeData{
  name: string;
  age: string;
  sex: string;
  address:string;
}