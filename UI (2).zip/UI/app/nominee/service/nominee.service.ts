import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import {NomineeData} from '../interface/nomineeData.interface';

//let makeNomineeUrl='put the url here';
let makeNomineeLabelUrl = 'api/nominee.json';
let nomineeDataInterface='api/nomineeData.json';

export interface Nominee{
  nomineeName: string;
  age: string;
  sex: string;
  address: string;
}

@Injectable()
export class NomineeService {
  constructor(private _http: Http
  ) 
  {
     console.log('calling the Nominee service');
  }
  
  getMakeNomineeLabels() 
  {
      return this._http.get(makeNomineeLabelUrl).map((response:Response)=>
      <Nominee>response.json().data)
      .do(data=>console.log(data))
      .catch(
        this.handleError)
    ;
  }

  getNomineeData() 
  {
      console.log('in get NomineeData');
      return this._http.get(nomineeDataInterface).map((response:Response)=>
      <NomineeData>response.json().data)
      .do(data=>console.log(data))
      .catch(
        this.handleError);
  }
  
  
  private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
 
}