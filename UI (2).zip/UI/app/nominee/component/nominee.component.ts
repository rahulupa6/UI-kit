import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Nominee,NomineeService } from '../service/nominee.service';




@Component({
    selector: 'nominee',
   templateUrl: 'app/nominee/view/nominee.component.html',
    directives: [ROUTER_DIRECTIVES],
    //directives: [ROUTER_DIRECTIVES],
    providers: [
        NomineeService
    ]
})



export class NomineeComponent implements OnDestroy, OnInit {

    nomineeLabels: Nominee;
    errorMessage: string;
   
    constructor(private _nomineeService: NomineeService,
				private _router: Router) {  
    }

	back(){
	this._router.navigate(['Shell']);
	}
 
    getNomineeLabel() {
        console.log("Calling the getPaymentLabel");
        	this.nomineeLabels= {};
		this._nomineeService.getMakeNomineeLabels()
					 .subscribe(
                       nominee =>{
                            this.nomineeLabels = nominee;
                                       
                       });
           
                   
    }
	
	getNomineeData() {
        console.log("Calling the nomineeData");
        this.nomineeData= {};
		this._nomineeService.getNomineeData()
		.subscribe(
            Nominee =>{
                      this.nomineeData = Nominee;
                      console.log(this.nomineeData);
                      console.log(Nominee);
                    }
         );
    
	
    makeNominee()
    {
        alert("helloWorld");
       console.log("inside Nominee section");
    }

    ngOnDestroy() {
    }

    ngOnInit() {
	 console.log("On it");
        this.getNomineeLabel();
       // console.log(this.nomineeLabels.cardNumber);
        
        
    }
    
}


