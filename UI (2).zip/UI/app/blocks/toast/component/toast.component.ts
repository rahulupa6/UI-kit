import { Component, OnInit } from 'angular2/core';

import { ToastService } from '../service/toast.service'

@Component({
  selector: 'toast',
  templateUrl: 'app/blocks/toast/view/toast.component.html'
 // styleUrls: ['app/blocks/toast/toast.component.css']
})
export class ToastComponent implements OnInit {
  private _defaults = {
    title: '',
    message: 'May the Force be with You',
    type:'Success'
  };
  title: string;
  message: string;
  type: string;

  private _toastElement: any;
  private _divtoastElement: any;

  constructor(toastService: ToastService) {
    toastService.activate = this.activate.bind(this);
  }

  activate(message = this._defaults.message, title = this._defaults.title, type = this._defaults.type) {
    this.title = title;
    this.message = message;
    this.type = type;
    this._show();
  }

  ngOnInit() {
      this._toastElement = document.getElementById('toast');
      this._divtoastElement = document.getElementById('divToast');
    
  }

  private _show() {
  console.log(this.type);
      if (this.type == 'Success')
          this._divtoastElement.className = "toast-card-green mdl-shadow--16dp"
      else
          this._divtoastElement.className = "toast-card-red mdl-shadow--16dp"

    console.log(this.message);
    this._toastElement.style.opacity = 1;
    this._toastElement.style.zIndex = 9999;
   
    window.setTimeout(() => this._hide(), 3000);
  }

   _hide() {
    this._toastElement.style.opacity = 0;
    window.setTimeout(() => this._toastElement.style.zIndex = 0, 400);
  }
}
