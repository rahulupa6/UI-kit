import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import {PaymentService } from '../service/payment.service';
import {Payment} from '../interface/paymentLabel.interface';

import { ToastService } from 'app/blocks/blocks';

export class PaymentData {
    policyNumber: string;
  policyName: string;
  paymentDue: string;
  cardType:string;
  cardNumber:string;
  cvv:string;
  payNow:string ;
status:string;  
    constructor() {
       }
}
@Component({
    selector: 'make-payment',
   
   templateUrl: 'app/make-payment/payment/view/payment.component.html',
    directives: [ROUTER_DIRECTIVES],
    //directives: [ROUTER_DIRECTIVES],
    providers: [
        PaymentService
    ]
})



export class MakePaymentComponent implements OnDestroy, OnInit {
	otpOff:boolean;
    paymentLabels: Payment;
	errMsgOtp:string
	otpCnt:number;
    errorMessage: string;
    paymentData:PaymentData;
	IsPaymentDone:boolean;
   // paymentData: PaymentData;
   
	
    constructor(private _paymentService: PaymentService,
				  private _toastService: ToastService,
				private _router: Router) {  
    }

	back(){
	this._router.navigate(['Home']);
	}
 
    getPaymentLabel() {
        console.log("Calling the getPaymentLabel");
        	this.paymentLabels= '';
		this._paymentService.getMakePaymentLabels()
					 .subscribe(
                       payment =>{
                            this.paymentLabels = payment;
                                       
                       });
           
                   
    }
	askForOTP()
	{
		
		if(this.otpCnt>2)
		{
			 this.errMsgOtp = "The limit exceeded for OTP";
		}
		else
		{
			if (this.serviceOtp == this.otp)
			{	
			
			     this.otpOff=true;
				 this.paymentData.policyNumber= sessionStorage.getItem("polNo");
				 this.paymentData.paymentDue= "2000";
				}
			else
			{
				this.otpCnt++;
				this.errMsgOtp = "Invalid OTP";
			}
		}

	}
    makePayment(payData)
    {   
		
			this._paymentService.makePayment(payData).subscribe(
                       success =>{
					   this.errorMessage="Your Payment is "+success.paymentStatus;
					   //this.IsPaymentDone=true;
					
                           console.log("PayData"+payData);
						   this._toastService.activate("Your payment transaction is success", "", "Success");
                            this._router.navigate(['Shell']);           
                       });
					   
		
		/*if(this.otpCnt>2)
		{
			 this.errMsgOtp = "The limit exceeded for OTP";
		}
		else
		{
			if (this.serviceOtp == this.otp)
			{	
			//alert("Inside The Make Payment");
			
					
    
				//
				}
			else
			{
				this.otpCnt++;
				this.errMsgOtp = "Invalid OTP";
			}
		}*/


 
    }

    ngOnDestroy() {
    }


    ngOnInit() {
	this.errMsgOtp=""
	this.otpCnt=0;
	this.otpOff=false;
	this.IsPaymentDone=false;
        this.getPaymentLabel();
        this.paymentData=new PaymentData();
		this.getOtpCall();
    
    }
		
		
	private getOtpCall()
  {	
		
		 
		   console.log("get OTP");
				var userId=sessionStorage.getItem('userId');
				this.serviceOtp = "1234";
			return;
		// this._paymentService.getOTP()
            // .subscribe(logins => {
					// console.log("after otp-"+logins);
                // if (logins == "-1")
                    // this.errMsg = logins;
                // else {
					    // this.otpOff=false;
						// this.serviceOtp = logins;
						// console.log('Success-' + this.serviceOtp);
						// this.errMsg = "";
						// this.otpCnt=0;
                // }

            // });
}

	
    
}


