System.register(['angular2/core', 'angular2/router', '../service/payment.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, payment_service_1;
    var PaymentData, MakePaymentComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (payment_service_1_1) {
                payment_service_1 = payment_service_1_1;
            }],
        execute: function() {
            PaymentData = (function () {
                function PaymentData() {
                }
                return PaymentData;
            }());
            exports_1("PaymentData", PaymentData);
            MakePaymentComponent = (function () {
                // paymentData: PaymentData;
                function MakePaymentComponent(_paymentService, _router) {
                    this._paymentService = _paymentService;
                    this._router = _router;
                }
                MakePaymentComponent.prototype.back = function () {
                    this._router.navigate(['Home']);
                };
                MakePaymentComponent.prototype.getPaymentLabel = function () {
                    var _this = this;
                    console.log("Calling the getPaymentLabel");
                    this.paymentLabels = '';
                    this._paymentService.getMakePaymentLabels()
                        .subscribe(function (payment) {
                        _this.paymentLabels = payment;
                    });
                };
                MakePaymentComponent.prototype.makePayment = function (payData) {
                    // console.log(payData);
                    this._paymentService.makePayment(payData);
                };
                MakePaymentComponent.prototype.ngOnDestroy = function () {
                };
                MakePaymentComponent.prototype.ngOnInit = function () {
                    this.getPaymentLabel();
                    this.paymentData = new PaymentData();
                    // console.log(this.paymentLabels.cardNumber); 
                };
                MakePaymentComponent = __decorate([
                    core_1.Component({
                        selector: 'make-payment',
                        //template:`<H1>Hi SHubham Jain</H1>`,
                        templateUrl: 'app/make-payment/payment/view/payment.component.html',
                        directives: [router_1.ROUTER_DIRECTIVES],
                        //directives: [ROUTER_DIRECTIVES],
                        providers: [
                            payment_service_1.PaymentService
                        ]
                    }), 
                    __metadata('design:paramtypes', [payment_service_1.PaymentService, router_1.Router])
                ], MakePaymentComponent);
                return MakePaymentComponent;
            }());
            exports_1("MakePaymentComponent", MakePaymentComponent);
        }
    }
});
//# sourceMappingURL=payment.component.js.map