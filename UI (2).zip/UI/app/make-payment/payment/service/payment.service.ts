﻿import { Injectable } from 'angular2/core';
import { Http, Response,Headers } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import {Payment} from '../interface/paymentLabel.interface';
import {PaymentData} from '../component/payment.component';

import { CONFIG } from 'common/config.ts';

let makePaymentUrl=CONFIG.baseUrls.makePaymentsUrl;
let makePaymentLabelUrl =CONFIG.baseUrls.makePaymentsLabelUrl;
let paymentServiceUrl=CONFIG.baseUrls.PaymentServiceUrl; 



@Injectable()
export class PaymentService {
  paymentData:PaymentData;
  constructor(private _http: Http
  ) 
  {
     console.log('calling the Payment service');
  }
  
  getMakePaymentLabels() 
  {
      return this._http.get(makePaymentLabelUrl).map((response:Response)=>
      <Payment>response.json().data)
      .do(data=>console.log(data))
      .catch(
        this.handleError)
    ;
  }
  makePayment(payData)
  {
  
    this.paymentData=payData;
	this.paymentData.cardType="visa";
	//console.log("Inside Service"+payData)
   // return this._http.put(makePaymentUrl,payData);
   this.paymentData.userId =sessionStorage.getItem('userId');
this.paymentData.status="success";

		 let headers = new Headers();
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  //let headers = new Headers({ "Content-Type": "application/json" },{ "Access-Control-Allow-Origin": "*"});
          //let options = new RequestOptions({ headers: headers });

			let body = JSON.stringify(this.paymentData);
			console.log('body' + body);
					

        return this._http
            .post(paymentServiceUrl, body,{headers : headers})
            .map((response: Response) => response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();

  }

  getOTP()
	{
		

		 let headers = new Headers();
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		 
			//let body = JSON.stringify(this.userDet);
			let body = '{"userName":"'+sessionStorage.getItem('userId')+'","mobile":"9930116432"}';
			console.log('body' + body);
			
			 return this._http
            .post("http://syndigitalportal.cloudapp.net/multiauth/api/MultiAuth", body,{headers : headers})
            .map((response: Response) => response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();
	}

  private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }

  
    authenticate() {

       console.log(this.otp);
		
	
    }
	
 
}