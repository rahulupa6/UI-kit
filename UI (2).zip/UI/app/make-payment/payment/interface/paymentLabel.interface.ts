export interface PaymentData{
  policyNumber: string;
  PaymentDue: string;
  cardType:string;
  cardNumber:string;
  cvv:string;
  payNow:string ;

}