﻿import { Injectable } from 'angular2/core';
import { Http, Response, Headers, RequestOptions } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import { CONFIG } from 'common/config.ts';

let CallBackUrl = CONFIG.baseUrls.callBackUrl;
let serviceUrl = CONFIG.baseUrls.callMePostUrl;

export interface ICallBackLabel {
    EnterMobileNo: number;
    SelectDate: string;
    SelectTime: string;
    Time1: string;
    Time2: string;
    Time3: string;
    Time4: string;
    CallMe: string;
}
export interface ICallBackData {
    userId: string;
    mobileNumber: number;
    date: string;
    timeSlot: string;
}
export interface ICallBack
{
    CallBackLabel: ICallBackLabel;
    CallBackData: ICallBackData;
}

@Injectable()
export class CallBackService {
    constructor(private _http: Http
        ) {
        console.log('CallBack load');
    }

    getcallBack() {
        console.log(CallBackUrl);

        return this._http.get(CallBackUrl)
            .map((response: Response) => <ICallBackLabel>response.json())
            .do(data => console.log(data))
            .catch(this.handleError)
            .finally();
    }

    submitCallBack(callBackData: ICallBackData) {
        console.log(callBackData);

      
        let headers = new Headers({ "Content-Type": "application/json" });
        let options = new RequestOptions({ headers: headers });

			//let body='{"Type":"Message","Text":"'+message+'"}';  
			
		let body = JSON.stringify(callBackData);

        console.log(serviceUrl + body);
		//{"userId":"VR5032386","date":"2015-01-02","mobileNumber":"88975350744","timeSlot":"11Am - 1PM"}
        //callBackData.userId = "VR5032386";
        callBackData.userId = sessionStorage.getItem('userId');

        return this._http
            .post(serviceUrl, body, { headers: headers })
            .map((response: Response) => response.json())
            .do(d=> console.log("Response" + JSON.stringify(d)))
            .catch(this.handleError)
            .finally();

    }

    handleError(err: any)
    {
        console.log("Error: " + err);
     }


}