import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import { ICallBackLabel, ICallBackData, ICallBack, CallBackService } from '../service/callback.service';
import { ToastService } from 'app/blocks/blocks';


@Component({
    selector: 'call-back',
    templateUrl: 'app/call-back/view/call-back.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers:[CallBackService]
})

export class CallBackComponent implements OnInit {
   
	callback: ICallBack;
	
    
    constructor(private _callBackService: CallBackService,
                   private _toastService: ToastService,
	                    private _router: Router) {
        console.log('CallBack');
    }
    /*login() {
        this._router.navigate(['Home']);
           }*/

    callBackLabel() {
        this.callback ={};
		this.callback.CallBackLabel={};
		this.callback.CallBackData={};
		this._callBackService.getcallBack()
			.subscribe(callback => {
			if(callback != undefined)
			{
			this.assignCallLabel(callback);
			}
			//this.callback=callback;
			});

			console.log(this.callback);
    }
	
	assignCallLabel(res:any)
	{
	  this.callback.CallBackLabel.EnterMobileNo=res.FieldName1;
	  this.callback.CallBackLabel.SelectDate=res.FieldName2;
	  this.callback.CallBackLabel.SelectTime=res.FieldName3;
	  this.callback.CallBackLabel.Time1=res.FieldName4;
	  this.callback.CallBackLabel.Time2=res.FieldName5;
	  this.callback.CallBackLabel.Time3=res.FieldName6;
	  this.callback.CallBackLabel.Time4=res.FieldName7;
	  this.callback.CallBackLabel.CallMe=res.FieldName8;
	  
     }

       submitCallData()
     {
           
           this._callBackService.submitCallBack(this.callback.CallBackData)
               .subscribe(response=> console.log(response));
         

           this._toastService.activate("Your Request accepted.We will call you soon", "", "Success");
           //this._router.navigate(['Shell']);
       
     }
	 ngOnInit() 
	 {
        this.callBackLabel();
     }
	
}

