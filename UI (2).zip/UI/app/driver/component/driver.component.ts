import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router,RouteParams } from 'angular2/router';
import {DriverService } from '../services/driver.service';
import {Driver} from '../interface/driverLabel.interface';

export class DriverData {
    firstName: string;
    lastName: string;
    dob: string;
    maritalStatus:string;
    sex:string;
    drivingLicence:string;
    ssn:string ;  
    
  
    constructor() 
    {
        console.log('in DriverData constructor');    
    }
}
@Component({
    selector: 'driver-data',
    templateUrl: 'app/driver/view/driver.component.html',
    directives: [ROUTER_DIRECTIVES],
    providers: [
        DriverService
    ]
})
export class DriverDataComponent implements OnDestroy, OnInit {

    driverLabels: Driver;
    errorMessage: string;
    driverData:DriverData;
   // driverData: DriverData;
   
	
    constructor(private _driverService: DriverService,
				private _router: Router,private _routeParams:RouteParams) {
    }

	back(){
	this._router.navigate(['DriverList']);
	}
 save()
 {
 console.log(this.driverData);
  this._driverService.postDriver(this.driverData);
 }
    getDriverLabel() {
        console.log("Calling the driverLabel");
        	this.driverLabels= '';
		this._driverService.getDriverLabels()
		.subscribe(
            Driver =>{
            this.driverLabels = Driver;
        });
        this.getDriverData();
           
                   
    }
       getDriverData() {
        console.log("Calling the driverData");
        this.driverData= '';
		this._driverService.getDriverData()
		.subscribe(
            Driver =>{
                      this.driverData = Driver;
                      console.log(this.driverData);
                      console.log(Driver);
                    }
         );
    }
    ngOnDestroy() {
    }
    ngOnInit() {
        this.driverData=new DriverData();
        this.getDriverLabel();
		   let id = this._routeParams.get('id');
	   if(id!=null){
	   console.log(id);
	    this._driverService.getDriver(id)
					.subscribe(
					Driver =>{
                      this.driverData = Driver;
                      console.log(this.driverData);
                      console.log(Driver);
                    }
					
					);
					}
					else
					{
						this.getDriverData();
					}

       }
}