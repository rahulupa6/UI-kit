System.register(['angular2/core', 'angular2/router', '../services/driver.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, driver_service_1;
    var DriverData, DriverDataComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (driver_service_1_1) {
                driver_service_1 = driver_service_1_1;
            }],
        execute: function() {
            DriverData = (function () {
                function DriverData() {
                }
                return DriverData;
            }());
            exports_1("DriverData", DriverData);
            DriverDataComponent = (function () {
                // driverData: DriverData;
                function DriverDataComponent(_driverService, _router) {
                    this._driverService = _driverService;
                    this._router = _router;
                }
                DriverDataComponent.prototype.back = function () {
                    this._router.navigate(['Home']);
                };
                DriverDataComponent.prototype.getDriverLabel = function () {
                    var _this = this;
                    console.log("Calling the driverLabel");
                    this.driverLabels = '';
                    this._driverService.getDriverLabels()
                        .subscribe(function (Driver) {
                        _this.driverLabels = Driver;
                    });
                };
                DriverDataComponent.prototype.ngOnDestroy = function () {
                };
                DriverDataComponent.prototype.ngOnInit = function () {
                    this.getDriverLabel();
                    this.driverData = new DriverData();
                    // console.log(this.driverLabels.cardNumber); 
                };
                DriverDataComponent = __decorate([
                    core_1.Component({
                        selector: 'driver-data',
                        //template:`<H1>Hi SHubham Jain</H1>`,
                        templateUrl: 'app/driver/view/driver.component.html',
                        directives: [router_1.ROUTER_DIRECTIVES],
                        //directives: [ROUTER_DIRECTIVES],
                        providers: [
                            driver_service_1.DriverService
                        ]
                    }), 
                    __metadata('design:paramtypes', [driver_service_1.DriverService, router_1.Router])
                ], DriverDataComponent);
                return DriverDataComponent;
            }());
            exports_1("DriverDataComponent", DriverDataComponent);
        }
    }
});
//# sourceMappingURL=driver.component.js.map