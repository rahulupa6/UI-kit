﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import {Driver} from '../interface/driverLabel.interface';
import {DriverData} from '../component/driver.component';
import { CONFIG } from 'common/config.ts';

let driverUrl=CONFIG.baseUrls.driversUrl;
let driverDataInterface=CONFIG.baseUrls.driversDataUrl;
let driverLabelUrl =CONFIG.baseUrls.driverLabelsUrl;


@Injectable()
export class DriverService {
  driverData:DriverData;
  
  constructor(private _http: Http) 
  {
     console.log('calling the Driver service');
  }
  
  getDriverLabels() 
  {
      console.log('in get DriverLabels');
      return this._http.get(driverLabelUrl).map((response:Response)=>
      <Driver>response.json().data)
      .do(data=>console.log(data))
      .catch(
        this.handleError);
  }
  getDriverData() 
  {
      console.log('in get DriverData');
      return this._http.get(driverDataInterface).map((response:Response)=>
      <DriverData>response.json().data)
      .do(data=>console.log(data))
      .catch(
        this.handleError);
  }
   getDriver(id: number) {
    return this.getDriverData()
      .map(drivers => drivers.find(driver => driver.id == id));
  }
   postDriver(driver:Driver){
  
  console.log(driver);  
  
  }
  private handleError (error: any) {
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
}