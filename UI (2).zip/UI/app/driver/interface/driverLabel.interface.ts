export interface Driver{
	id:number;
  firstName: string;
  lastName: string;
  dob: string;
  maritalStatus:string;
  sex:string;
  drivingLicence:string;
  ssn:string ;
  save:string;
  back:string;

}