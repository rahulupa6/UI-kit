﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';


let vehiclesUrl = CONFIG.baseUrls.vehicleListUrl;

export interface Vehicle {
  id: number;
  name: string;
  type: string;
  vehicleIdentityNumber:string
}

@Injectable()
export class VehicleService {
  constructor(private _http: Http
  ) {
      console.log('vehicle load');
  }

  getVehicles() {
      console.log(vehiclesUrl);

    return this._http.get(vehiclesUrl)
      .map((response: Response) => 
      <Vehicle[]>response.json().data)
	   .do(data => console.log(data[0].vehicleIdentityNumber))
      .catch(this.handleError)
     
  }
  
  private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
 

 
}