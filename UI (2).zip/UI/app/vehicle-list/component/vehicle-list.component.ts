import { Component, OnDestroy, OnInit, ViewChild } from 'angular2/core';
import { ROUTER_DIRECTIVES,Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import { Vehicle,VehicleService } from '../service/vehicle.service';
import{vehicles } from 'app/policy-details/service/policy-details.service';
import { ToastService } from 'app/blocks/blocks';

@Component({
    selector: 'story-vehicles',
    templateUrl: 'app/vehicle-list/view/vehicle-list.component.html',
      styleUrls: ['css/profileDetail.css'],
   directives: [ ROUTER_DIRECTIVES],
   	providers :[VehicleService]
})
export class VehicleListComponent implements OnDestroy, OnInit {

   
	vehicleList:vehicles[];
	
    constructor(
        private _router: Router, private _toastService: ToastService,private _vechileService:VehicleService) { 
                     this.vehicles = []; 
                     /*this.filteredVehicles=this.vehicles*/
    }

	back(){
       
        this._toastService.activate("Toaster created fail", "Added", "Fail");
        this._router.navigate(['Shell']);
	}
 
    getVehicles() {
        
			
	 	
					
					this.vehicleList=JSON.parse(sessionStorage.getItem('PolicyDetails')).vehicles;
					console.log("vehicleList:",this.vehicleList);
     }

    ngOnDestroy() {
    }

    ngOnInit() {
        this.getVehicles();
    }
}
