﻿
import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

let ForgetPasUrl="api/ForgetPass.json"


export interface ForgetPass
{
	
	ForgetPassword:"string";
	EmailAddress:"string";
	Submit:"string";
	Login:"string";\\added
	sendEmail(string):string;
	
}
@Injectable()
export class ForgetPasService
{
 constructor(private private _http: Http
  ) {
      console.log('ForgetPass load');
  }

  getDetails() {
      console.log(ForgetPasUrl);

    return this._http.get(ForgetPasUrl)
      .map((response: Response) => <ForgetPass>response.json().data)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

 sendEmail(Email)
{
  let email=Email;
  console.log(email);
  return email;
}
  
}
