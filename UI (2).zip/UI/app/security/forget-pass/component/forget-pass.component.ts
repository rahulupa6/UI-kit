import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import {ForgetPass,ForgetPasService} from '../service/forget-pass.service'

@Component({
    selector: 'router-outlet',
    templateUrl: 'app/security/forget-pass/view/forget-pass.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers:[ForgetPasService]
	
})

export class ForgetPassComponent implements OnInit()
{
	
	TextBox:string;
	emails:ForgetPass;

	constructor(private _forgetService:ForgetPasService,private _router: Router) {
        console.log('forget Password');
		}
		
		getForgetPas()
		{
		  this.emails ='';
		this._forgetService.getDetails()
			.subscribe(emails => {
			this.emails=emails;
			});

			console.log(this.emails);
		}
		getEmail(Email)
		{
		 let bo = this._forgetService.sendEmail(Email);
		 console.log(bo);
		 this._router.navigate(['Login']);//added

		}
		ngOnInit() {
        this.getForgetPas();
    }
}