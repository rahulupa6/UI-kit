import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import {UserLogin, LoginService} from '../service/login.service'

@Component({
    selector: 'login',
    templateUrl: 'app/security/login/view/login.component.html',
    directives: [ROUTER_DIRECTIVES],
    providers: [LoginService]
})




export class LoginComponent implements ngOnInit{
    userLogin: UserLogin;
	otp: string;
    otpOff: boolean;
    output: string;
    errMsg: string;
	otpCnt:int;
	userName:string;

    constructor(private _loginService: LoginService,
        private _router: Router) {

		console.log("login");
    }

	 login() {

       //this._router.navigate(['Home']);
       
  
		/* let res = this._loginService.authenticate(this.userLogin.User)
		if(res != "-1")
		{
				this.output = res;
                console.log('Success-' + this.output);
                this.otpOff = false;
				this.errMsg = "";
				this.otpCnt=0;
				// this._router.navigate(['Home']);
		}
		else
			this.errMsg = "Invalid Id" */
			
			
          let res = this._loginService.authenticate(this.userLogin.User)

            .subscribe(logins => {
					console.log("after auth-"+logins)
                if (logins.authentication == false)
                    this.errMsg = logins.otp;
                else {
					   //this.getOtpCall();
					     sessionStorage.setItem("userName",logins.userName);
						 this.output = logins.otp;
						 this.output=this.output.replace('"','');
						 this.output=this.output.replace('"','');
						console.log('Success-' + this.output);
						this.otpOff = false;
						this.errMsg = "";
						this.otpCnt=0; 
						sessionStorage.setItem('userId',this.userLogin.User.userId);
				console.log("authenticate-"+sessionStorage.getItem('userId'))
				this._router.navigate(['Home']);
						
                }

            });
			
        console.log('red' + res);  
		/*sessionStorage.setItem('userId',this.userLogin.User.userId);
		this._router.navigate(['Home']);*/
    }

	
    authenticate() {

       console.log(this.otp);
		
		if(this.otpCnt>2)
		{
			 this.errMsg = "The limit exceeded for OTP";
		}
		else
		{
			if (this.output == this.otp)
			{
				sessionStorage.setItem('userId',this.userLogin.User.userId);
				console.log("authenticate-"+sessionStorage.getItem('userId'))
				this._router.navigate(['Home']);
				
				//
				}
			else
			{
				this.otpCnt++;
				this.errMsg = "Invalid OTP";
			}
		}
    }
	
	getOtpCall()
  {	
     console.log("get OTP");
	 
	this._loginService.getOTP(this.userLogin.User)
            .subscribe(logins => {
					console.log("after otp-"+logins);
                if (logins == "-1")
                    this.errMsg = logins;
                else {
					   
						this.output = logins;
						console.log('Success-' + this.output);
						this.otpOff = false;
						this.errMsg = "";
						this.otpCnt=0;
                }

            });
}

	

    /*Surya Start Added Code*/

    getLogins() {
        this.userLogin = {};
       
        this.userLogin.Login = {};
        this.userLogin.User = {};

        this._loginService.getLogin()
            .subscribe(logins => {
			this.assignResponse(logins)
                //this.userLogin.Login = logins;
               
            });
        
    }
	
	assignResponse(res : any)
	{ 
	console.log('ans:'+res.ButtonName);
	this.userLogin.Login.Submit=res.ButtonName;
    console.log('ans:'+res.ButtonName);
	this.userLogin.Login.UserName=res.FieldName1;
	
	this.userLogin.Login.Password=res.FieldName2;
	
	this.userLogin.Login.ForgetPassword=res.FieldName4;
	this.userLogin.Login.Registration=res.FieldName3;
	
	this.userLogin.Login.SignIn="Sign In";
	
	
	}

     ngOnInit() {
        this.otpOff = true;
        this.errMsg = ""
		
        this.getLogins();


    }

}