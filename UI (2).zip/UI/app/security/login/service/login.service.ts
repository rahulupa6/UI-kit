﻿import { Injectable } from 'angular2/core';
import { Http, Response,RequestOptions,Headers } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';

let LoginUrl = CONFIG.baseUrls.LoginUrl;
let authUrl = CONFIG.baseUrls.AuthUrl;

export interface Login {
    UserName: string;
    Password: string;
    Submit: string;
    ForgetPassword: string;
    Registration: string;
    SignIn: string;
}

export interface User {
    userId: string;
    password: string;
}

export interface UserLogin {
    Login: Login;
    User: User;
}

export interface UserDetail
{
	UserName: string;
	Mobile : string;
}

@Injectable()
export class LoginService {
loggedIn=false;  //vipul
	userDet : UserDetail;
	//header: Headers;
    constructor(private _http: Http) {

    }

    getLogin() {

		 let headers = new Headers({ 'Access-Control-Allow-Origin': '*' });
         let options = new RequestOptions({ headers: headers });

        return this._http.get(LoginUrl,this.options)
            .map((response: Response) => (response.json()))
            .do()
            .catch()
            .finally();
    }


    authenticate(user: User): Observable<any> {
        console.log('res');
         // let headers = new Headers({ 'Access-Control-Allow-Origin': '*' });
        //  let options = new RequestOptions({ headers: headers });

		  


		//let headers = new Headers({ 'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS' });


		/*if(user.userName == "vr5032386")
		{
			this.loggedIn = true;  //vipul
			localStorage.setItem('jwt', user.userName); //vipul
			localStorage.setItem('CustId', "1"); //vipul
			return "123456";
		}
		else
			return "-1";*/

		
		/*this.userDet={};
		this.userDet.UserName=user.userName;
		this.userDet.Mobile="9930116432";*/

		let headers = new Headers();
		 //this.header.append('Authorization', '1234');  
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  //let headers = new Headers({ "Content-Type": "application/json" },{ "Access-Control-Allow-Origin": "*"});
          //let options = new RequestOptions({ headers: headers });

			let body = JSON.stringify(user);
			console.log('body' + body);
					
		
		//console.log(localStorage.getItem('userId'));
		
        return this._http
            .post(authUrl, body,{headers : headers})
            .map((response: Response) => response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();
			
    }
	
	getOTP(user: User)
	{
		this.userDet={};
		this.userDet.UserName=user.userName;
		this.userDet.Mobile="9930116432";

		 let headers = new Headers();
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		 
			let body = JSON.stringify(this.userDet);
			//let body = '{"userName":"'+user.userName+'","mobile":"9930116432"}';
			console.log('body' + body);
			
			 return this._http
            .post("http://digitalportal.cloudapp.net/MultiAuthAPI/api/MultiAuth", body,{headers : headers})
            .map((response: Response) => response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();
	}

	//vipul
	logout()
	{
		localStorage.removeItem('jwt');
		this.loggedIn = true;
	}
	//vipul
	isLoggedIn() {
    return this.loggedIn;
  }

    extractData(res: Response) {
        let body = res.json();
        console.log(body);
		
        return body.data || {};
    }

    handleError(error: any) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Observable.throw(errMsg);
    }


}