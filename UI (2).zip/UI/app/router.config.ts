﻿import { Dashboard } from '../app/components/dashboard/dashboard';

import { LoginComponent } from '../app/components/login/login';

export const routes = [
    { path: '/', component: Dashboard, name: 'List', useAsDefault: true },
    { path: '/login', component: LoginComponent, name: 'Login'}
];
