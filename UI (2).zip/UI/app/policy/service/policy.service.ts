﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';
let policyUrl = CONFIG.baseUrls.policyyUrl;

export interface IPolicy {
  policyNumber: number;
  vehicle: String;
  driver: String;
  vehicleFinanced: String;
  finance: String;
  submit: String;
  addVehicle: String;
  addDriver: String;
  startDate: String;
  endDate: String;
  
}


export interface IPolicyData
  {
  PolicyData:IPolicy;
  
  }

@Injectable()
export class PolicyService {

  constructor(private _http: Http) {
      
  }

  getPolicyDetails() {
    
	console.log('service');
	   
	   return this._http.get(policyUrl)
      .map((response: Response) => <IPolicy[]>response.json().data)
	     .do(data => console.log(data))
      .catch(this.handleError)
      .finally();


	 

  }

  
  
  getPolicies(policyNumber: number) {
     return this.getPolicyDetails()
      .map(polices => polices.find(p => p.policyNumber == policyNumber));

	  console.log(this.PolicyData);
  }
 
}