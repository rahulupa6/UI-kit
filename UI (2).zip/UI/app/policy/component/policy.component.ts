﻿import {Component, Injectable } from 'angular2/core';
import {RouteParams,RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { IPolicyData,PolicyService } from '../service/policy.service';
import { Observable, Subscription } from 'rxjs/Rx';
@Component({
    selector: 'policy',
    templateUrl: 'app/policy/view/policy.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers :[PolicyService]
})



export class PolicyComponent implements OnDestroy, OnInit {
    policy: IPolicyData;

    constructor(private _policyService: PolicyService,
				private _router: Router,
				private _routeParams:RouteParams) {  
    }
    
	back(){
	this._router.navigate(['PolicyList']);
	}

	

	getLables(){
  
  this.policy ={};

  this.policy.PolicyData={};
  
 
  
  }
 


    ngOnDestroy() {
    }



    ngOnInit() {
	
	   let policyNumber = this._routeParams.get('policyNumber');
	   this.policy ={};
	   this.policy.PolicyData={};	
	   this._policyService.getPolicies(policyNumber)
					.subscribe(policy => {
								this.policy.PolicyData = policy;
								console.log(this.policy.PolicyData.policyNumber);						
	   }); 
       
    }

}