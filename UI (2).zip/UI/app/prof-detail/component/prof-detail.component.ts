import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import{CustomerComponent} from 'app/customer/component/customer.component';
import{DriverListComponent} from 'app/driver-list/component/driver-list.component';
import{VehicleListComponent} from 'app/vehicle-list/component/vehicle-list.component';
@Component({
    selector: 'profile-details',
   templateUrl: 'app/prof-detail/view/prof-detail.component.html',
    directives: [ROUTER_DIRECTIVES,CustomerComponent,DriverListComponent,VehicleListComponent]
     
})

export class ProfDetailsComponent  {
constructor(private _router: Router) {  
            console.log('prof details log');
    }


}
