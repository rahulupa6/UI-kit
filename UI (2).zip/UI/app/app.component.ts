﻿import {Component, Injectable,provide } from 'angular2/core';
import { RouteConfig, ROUTER_DIRECTIVES, ROUTER_PROVIDERS,Router } from 'angular2/router';
import { HTTP_PROVIDERS } from 'angular2/http';
import 'rxjs/Rx'; // load the full rxjs

import { Dashboard } from 'app/dashboard/component/dashboard.component';
import { LoginComponent } from 'app/security/login/component/login.component';

import {ForgetPassComponent} from 'app/security/forget-pass/component/forget-pass.component';
import {RegistrationComponent } from 'app/registration/component/registration.component';
import { LocationStrategy, Location, HashLocationStrategy } from 'angular2/router'; 


//import routes from '../app/router.config.ts';

@Component({
    selector: 'my-app',
    templateUrl: 'app/app.html',
    directives: [ROUTER_DIRECTIVES],
    providers: [
        ROUTER_PROVIDERS,
        HTTP_PROVIDERS,
        provide(LocationStrategy, { useClass: HashLocationStrategy }
    ]
})

@RouteConfig([{ path: '/login', component: LoginComponent, name: 'Login',useAsDefault: true },
    { path: '/dashboard/...', component: Dashboard, name: 'Home', useAsDefault: false}},
	{ path: '/forget-pass', component:ForgetPassComponent, name: 'ForgotPassword'},
	{ path: '/registration', component:RegistrationComponent, name: 'Registration'}
	
	 ]
)

//

export class AppComponent {
    constructor(private _router: Router) {
        console.log('app const');
   	 
	   //console.log(this._router.navigate(['Login']));

	//	this._router.navigate(['Login']);
	
    }

}