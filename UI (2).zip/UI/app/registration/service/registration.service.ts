﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
//import {CONFIG} from 'common/config.ts'

let RegUrl='api/registration.json'; 

export interface IRegisterLabel
{
 FirstName:string;
 LastName:string;
 EmailAddress:string;
 ResidentialAddress:string;
 MailingAddress:string;
 PhoneType:string;
 PhoneNumber:number;
 Submit:string;
 SaveForLater:string;
 Registration:string;
 Login:string;\\added
}

export interface IRegisterControl
{
 FirstName:string;
 LastName:string;
 EmailAddress:string;
 ResidentialAddress:string;
 MailingAddress:string;
 PhoneType:string;
 PhoneNumber:number;
}

export interface IRegister
{
 RegisterLabel:IRegisterLabel;
 RegisterControl:IRegisterControl;
}




@Injectable()
export class RegisterService {
  constructor(private _http: Http
  ) {
      console.log('Register load');
  }

  getRegisterLabel() {
      console.log(RegUrl);

    return this._http.get(RegUrl)
      .map((response: Response) => <IRegisterLabel>response.json().RegLabels)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }
  getRegisterData() {
    //console.log()
	return this._http.get(RegUrl)
	  .map((response:Response)=><IRegisterControl>response.json().RegData)
	   .do(data=>console.log(data))
	   .catch(this.handleError)
	   .finally();
  
  }
  submitDataService(RegisterControl:IRegisterControl) {
  console.log(RegisterControl);

  }


    

 
}

