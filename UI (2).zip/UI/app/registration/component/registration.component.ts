import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import {IRegisterLabel,IRegister,RegisterService} from '../service/registration.service'


@Component({
    selector: 'router-outlet',
    templateUrl: 'app/registration/view/registration.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers:[RegisterService]
	
})


export class RegistrationComponent implements OnInit()
{
 
	
	register:IRegister;
	

	constructor(private _registerService:RegisterService,private _router:Router)
	{
	  console.log('registration');
	}
	getRegisterLabels()
	{
	  this.register={};
	  this.register.RegisterLabel={};
	 this.register.RegisterControl={};

	  //console.log('comp -'+this.register.RegisterLabel);

	   this._registerService.getRegisterLabel()
	           .subscribe(register => {
				
				   this.register.RegisterLabel= register;
				   console.log('comp-'+this.register.RegisterLabel);
				});
				
	}
	

	submitData()
	{
	  console.log('com11-'+this.register.RegisterControl);
       this._registerService.submitDataService(this.register.RegisterControl); 
	    this._router.navigate(['Login']);\\added
	}
	
	 ngOnInit() {
        this.getRegisterLabels();
		
    }

}