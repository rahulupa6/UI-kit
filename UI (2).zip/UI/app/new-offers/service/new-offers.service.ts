﻿import { Injectable } from 'angular2/core';
import { Http, Response,RequestOptions,Headers } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import {CONFIG} from 'common/config.ts'

let NewUrl=CONFIG.baseUrls.NewsUrl;
let NewDataUrl=CONFIG.baseUrls.NewsDataUrl;
let FeedbackUrl=CONFIG.baseUrls.PostFeedbackURL

export interface OfferLabel
{
    PolicyNo: string;
    Amount: string;
    PolicyId: string;
    Name: string;
    Description: string;
    ReferenceNumber:string;
}

export interface OfferData
{
	policyNo:string;
	policyName:string;
	Description:string;
	Amount:string;
	Comment:string="";
}

@Injectable()
export class NewOffersService {
   
   constructor(private _http: Http) 
  {
      console.log('New Offers load');
  
  }

  getOffersLabel()
  {
  console.log(NewUrl);

    return this._http.get(NewUrl)
      .map((response: Response) => <OfferLabel>response.json())
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

  getOffersData()
  {
     console.log(NewDataUrl);
  		let headers = new Headers();
		 
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  //let headers = new Headers({ "Content-Type": "application/json" },{ "Access-Control-Allow-Origin": "*"});
          //let options = new RequestOptions({ headers: headers });

			let body = '{"userId":"'+sessionStorage.getItem('userId')+'"}';
			console.log('body' + body);
			
      return this._http.post(NewDataUrl,body,{headers : headers})
      .map((response: Response) => response.json().recommendedPolicies)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  

     /* return this._http.get(NewDataUrl,)
          .map((response: Response) => response.json().recommendedPolicies)
          .do(data => console.log(data))
          .catch(this.handleError)
          .finally();*/
  }


  submitFeedback(offerData: OfferData)
  {
     console.log(offerData);

	 let headers = new Headers();
		 
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  //let headers = new Headers({ "Content-Type": "application/json" },{ "Access-Control-Allow-Origin": "*"});
          //let options = new RequestOptions({ headers: headers });

			//let body = '{"userId":"'+sessionStorage.getItem('userId')+'"}';
			let body='{"userId":"'+sessionStorage.getItem('userId')+'","policyNumber":"'+offerData.policyNumber+'","comment":"'+offerData.Comment+'"}';
			console.log('body' + body);
			console.log(FeedbackUrl);
    return this._http.post(FeedbackUrl,body,{headers : headers})
      .map((response: Response) => response.json())
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  
  }

}

