import {Component, Injectable } from 'angular2/core';
import {RouteConfig, IPolicyHeaders, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import { OfferLabel, OfferData, NewOffersService } from '../service/new-offers.service';
import { ToastService } from 'app/blocks/blocks';



@Component({
    selector: 'new-offers',
    templateUrl: 'app/new-offers/view/new-offers.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers:[NewOffersService]
	
	
})


export class NewOffersComponent implements OnInit()
{
  offer:OfferLabel;
  //offerdata:OfferData[];
  offerList:OfferData[];
 feedback: string;
    constructor(private _newoffersService:NewOffersService, private _toastService: ToastService,private _router:Router)
	{
	this.offer={};

	  console.log('New Offers');
	}

	getOfferLabel()
	{
	  
	   this._newoffersService.getOffersLabel()
	           .subscribe(offer => {
			   if(offer!=undefined)
			   {
				   this.assignResponse(offer);
				   console.log(offer);
				   }
				   //this.register.RegisterLabel= register;
				   //console.log('comp-'+this.register.RegisterLabel);
				});
	 
	}
	assignResponse(newoffer:any)
	{
        this.offer.PolicyNo=newoffer.FieldName1;
        this.offer.PolicyId = newoffer.FieldName2;
        this.offer.Name = newoffer.FieldName3;
        this.offer.Description = newoffer.FieldName4;
        this.offer.Amount = newoffer.FieldName5;
        this.offer.ReferenceNumber = newoffer.FieldName6;
	}
	getOfferData()
	{
	this._newoffersService.getOffersData()
	           .subscribe(offerdata => {
			   if(offerdata!=undefined)
			   {
				  
				  //this.AssignResponse(offerdata);
				  this.offerList=offerdata;
					console.log("offerdata:"+this.offerList);
				  
			  }
				
				});
				

	}

	submitFeedback(offerData: OfferData)
	{
		console.log(offerData);
		
		this._newoffersService.submitFeedback(offerData)
		.subscribe(offerdata => {
            console.log("succces");
            this._toastService.activate("Thanks for your Valuable Feedback","", "Success");
		
        });

        

	           
	}
	
	//AssignResponse(polOffers:any)
	//{
	//	this.offerList=polOffers;
	//	for(var i=0;i<polOffers.length;i++)
	//	{
	//	   //this.offerList[i].policyNo=polOffers[i];
			
	//		this.offerList[i].Comment="";
			
	//		if(i%2 == 0)
	//		{
	//		  this.offerList[i].policyName="Upgrade Accident Forgiveness";
	//		  this.offerList[i].Amount="$2,058";
	//		  this.offerList[i].Description="Reference Number : 167615M5141154";
	//		  }
	//		else
	//		{
	//		  this.offerList[i].policyName="Protect Your Personal Items";
	//		  this.offerList[i].Amount="$3,558";
	//		  this.offerList[i].Description="Reference Number : 167615M53625272";
	//		 }
	//	}
	//}

	 ngOnInit() {
        this.feedback="";
		this.getOfferLabel();
		this.getOfferData();
    }

}