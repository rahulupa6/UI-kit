﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
//import {CONFIG} from 'common/config.ts'

let AddUrl='api/address.json'; 

export interface IAddressLabel
{
  Address:string;
  AddressLine1:string;
  AddressLine2:string;
  AddressLine3:string;
  City:string;
  State:string;
  Country:string;
  ZipCode:number;
  Save:string;
}

export interface IAddressControl
{
 AddressLine1:string;
 AddressLine2:string;
 AddressLine3:string;
 City:string;
 State:string;
 Country:string;
 ZipCode:number;
}

export interface IAddress
{
 AddressLabel:IAddressLabel;
 AddressControl:IAddressControl;
}




@Injectable()
export class AddressService {
  constructor(private _http: Http
  ) {
      console.log('Address load');
  }

  getAddressLabel() {
      console.log(AddUrl);

    return this._http.get(AddUrl)
      .map((response: Response) => <IAddressLabel>response.json().AddLabels)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }
  getAddressData() {
    //console.log()
	return this._http.get(RegUrl)
	  .map((response:Response)=><IAddressControl>response.json().AddData)
	   .do(data=>console.log(data))
	   .catch(this.handleError)
	   .finally();
  
  }
  submitAddService(AddressControl:IAddressControl) {
  console.log(AddressControl);

  }


    

 
}

