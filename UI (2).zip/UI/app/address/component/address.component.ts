import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import {Observable, Subscription } from 'rxjs/Rx';

import {IAddressLabel,IAddress,AddressService} from '../service/address.service'

@Component({
    selector: 'router-outlet',
    templateUrl: 'app/address/view/address.component.html',
    directives: [ROUTER_DIRECTIVES],
	providers:[AddressService]
	
})

export class AddressComponent implements OnInit
{
   address:IAddress;

   constructor(private _addressService:AddressService,private _router:Router)
	{
	  console.log('Address log');
	}

	getAddressLabels()
	{
	  this.address={};
	  this.address.AddressLabel={};
	  this.address.AddressControl={};
	  this._addressService.getAddressLabel()
	            .subscribe(address => {
				
				   this.address.AddressLabel= address;
				   console.log('comp-'+this.address.AddressLabel);
				});
	}
	saveAddress()
	{
	   this._addressService.submitAddService(this.address.AddressControl);
	}
	ngOnInit()
	{
	  this.getAddressLabels();
	}



}