﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';

let PaymentListUrl=CONFIG.baseUrls.PaymentListUrl;

export interface PaymentList {
PolicyNumber:string,
PaymentDue:string,
CardType:string,
CardNumber:number,
CVV:number
}

@Injectable()
export class PaymentListService {
  constructor(private _http: Http
  ) {
      console.log('payments load');
  }

  getPayment() {
      console.log(PaymentListUrl);

    return this._http.get(PaymentListUrl)
      .map((response: Response) => <PaymentList[]>response.json().data)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

 
}