﻿import { Component, OnDestroy, OnInit, ViewChild } from 'angular2/core';
import { ROUTER_DIRECTIVES,Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import { PaymentList,PaymentListService } from '../service/payment-list.service';

@Component({
    selector: 'payment-list',
    templateUrl: 'app/payment-list/view/payment-list.component.html',
    directives: [ ROUTER_DIRECTIVES],
	providers :[PaymentListService]
})
export class PaymentListComponent implements OnDestroy, OnInit {

    payments: PaymentList[];
    filteredPayments = this.payments;
	
    constructor(private _paymentListService: PaymentListService,
				private _router: Router) {  
    }

	back(){
	this._router.navigate(['Shell']);
	}
 
    getPayments() {
        this.payments = [];
			
		this._paymentListService.getPayment()
					.subscribe(payments => {
								this.payments = this.filteredPayments = payments;
					});
    }
	/*add()
	{
	this._router.navigate(['Driver']);
	}*/
    ngOnDestroy() {
    }

    ngOnInit() {
        this.getPayments();
    }
}
