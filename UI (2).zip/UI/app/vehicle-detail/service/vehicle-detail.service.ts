﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';


import { CONFIG } from 'common/config.ts';



let vehicleUrl = CONFIG.baseUrls.vehiclesUrl;

export interface IVehicle {
  id:number;
  year: number;
  maker: string;
  model:string;
  subModel: string;
  vehicleIdentityNumber:string;
  milesDriven:string;
  
}

export interface  IVehicleLables{
  id:number;
  year: string;
  maker: string;
  model:string;
  subModel: string;
  vehicleIdentityNumber:string;
  milesDriven:string;
  accident:string;
  save:string;
  saveforlater:string;
  back:string;
  }

  export interface IVehicleData
  {
  vehicleData:IVehicle;
  vehicleLables:IVehicleLables;
  }
@Injectable()
export class Vehicle_DetailService {
  constructor(private _http: Http
  ) {
      console.log('vehicle load');
  }

 

  getLables(){
  
   console.log(vehicleUrl);

    return this._http.get(vehicleUrl)
      .map((response: Response) => <IVehicleLables>response.json().Labels)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  
  
  }
  
   getVehicles() {
      console.log(vehicleUrl);

    return this._http.get(vehicleUrl)
      .map((response: Response) => <IVehicle[]>response.json().data)
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

  getVehicle(id: number) {
    return this.getVehicles()
      .map(vehicles => vehicles.find(vehicle => vehicle.id == id));
  }



  postVehicle(vehicle:IVehicle){
  
  console.log(vehicle);  
  
  }

 
}