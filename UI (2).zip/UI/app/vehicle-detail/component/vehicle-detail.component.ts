﻿import{Component} from 'angular2/core';
import { RouteParams,ROUTER_DIRECTIVES,Router} from 'angular2/router';
import { IVehicle,IVehicleLables,IVehicleData,Vehicle_DetailService } from '../service/vehicle-detail.service';
import { Observable, Subscription } from 'rxjs/Rx';
@Component({

selector:'vehicle-detail',
templateUrl:'app/vehicle-detail/view/vehicle-detail.component.html',
directives: [ ROUTER_DIRECTIVES],
providers:[Vehicle_DetailService]


})
export class VehicleComponent implements OnDestroy, OnInit{

vehicle:IVehicleData;

constructor(private _vehicleService: Vehicle_DetailService,
				private _router: Router,private _routeParams:RouteParams) { 			
    }
	
  save(){
 
  console.log(this.vehicle);
  this._vehicleService.postVehicle(this.vehicle);
  
  
  }
 

  getLables(){
  
  this.vehicle ={};

  this.vehicle.vehicleData={};
  this.vehicle.vehicleLables={};  

  this._vehicleService.getLables()
					.subscribe(vehicle => {
								this.vehicle.vehicleLables = vehicle;
								console.log(this.vehicle.vehicleLables);
					});	
  
  }
 
  back(){
	this._router.navigate(['Vehicles']);
  }

     ngOnDestroy() {
    }

    ngOnInit() {  
	 
	  this.getLables();	
	 
	   let id = this._routeParams.get('id');
	   if(id!=null){
	   console.log(id);
	    this._vehicleService.getVehicle(id)
					.subscribe(vehicle => {
								this.vehicle.vehicleData = vehicle;
								console.log(this.vehicle.vehicleData);
					});
					}
					else
					{
	this._vehicleService.getVehicles()
					.subscribe(vehicle => {
								this.vehicle.vehicleData = vehicle;
								console.log(this.vehicle.vehicleData);				
					}

	
	
    }
    


}