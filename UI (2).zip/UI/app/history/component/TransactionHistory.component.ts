import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import {TransactionHistoryService } from '../service/history.service';
import {TransactionHistoryContent} from '../interface/TransactionHistory.interface';


@Component({
    selector: 'view-transactionst',
   templateUrl: 'app/history/view/transactionHistory.component.html',
    directives: [ROUTER_DIRECTIVES],
   
    providers: [
        TransactionHistoryService
    ]
})



export class ViewTransactionComponent implements OnDestroy, OnInit {

    transactionHistory: TransactionHistoryContent[];
    errorMessage: string;
    transactionLabel:TransactionHistoryContent;
   // paymentData: PaymentData;
   
	
    constructor(private _transactionService: TransactionHistoryService,
				private _router: Router) {  
    }

	back(){
	this._router.navigate(['Shell']);
	}
 
    getTransactionData() {
       
        	this.transactionHistory= [];
            
            
		this._transactionService.gettransactionHistory()
					 .subscribe(
                       transactions =>{                       
                            this.transactionHistory = transactions;
                                  
                       });
         
            
    }
    
    getTransactonLabel() {
        
        	this.transactionLabel= '';
		this._transactionService.getTransactionHistoryLabels()
					 .subscribe(
                       transactionLabel =>{
                          
                            this.transactionLabel = transactionLabel;
                           
                                       
                       });
    }
    ngOnDestroy() {
    }

    ngOnInit() {
       this.getTransactonLabel();
       this.getTransactionData();
       // this.paymentData=new PaymentData();
       // console.log(this.paymentLabels.cardNumber); 
        
    }
    
}


