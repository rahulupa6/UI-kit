import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import {TransactionHistoryContent} from '../interface/TransactionHistory.interface';

let getTransactionLabels='api/transactionsLabel.json';
let getTransactionDataUrl = 'api/transactionHistory.json';



@Injectable()
export class TransactionHistoryService {
  transacationData:TransactionHistoryContent[];
  constructor(private _http: Http
  ) 
  {
 
  }
   getTransactionHistoryLabels()
   {
      return this._http.get(getTransactionLabels).map((response:Response)=>
      <TransactionHistoryContent>response.json().transactionLabels)
      .do(data=>console.log(data))
      .catch(
        this.handleError)
    ;
   }
  
    gettransactionHistory() {

    return this._http.get(getTransactionDataUrl).map((response: Response)=> 
   
    <TransactionHistoryContent[]>response.json().transactionHistory)
	   .do(data => console.log(data))
      .catch(this.handleError);
  }
  

  private handleError (error: any) {
    console.log("Inside error")
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
 
}