export interface TransactionHistoryContent{
  transactionId: string;
  policyNumber: string;
  policyName: string;
  premiumAmount:string;
  premiumDate:string;
}



