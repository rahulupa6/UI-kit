import {Component } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';


import {Horizontal,HorizontalService} from '../service/horizontal-menu.service';



@Component({
    selector: 'topmenu',
    templateUrl: 'app/personalize/horizontal-menu/view/horizontal-menu.component.html',
	 directives: [ROUTER_DIRECTIVES],
	 providers:[HorizontalService]
})



export class HorizontalMenuComponent {
      /*DashBoard:string="";
     VehicleList:string="";
     Address:string="";
    Customers:string="";
      MakePayment:string="";
  PaymentHistory:string="";
   DriverList:string="";
    SignOut:string="";
	  */
	  UserName:string;
	  horizontal:Horizontal;

     constructor(private _horizontalService:HorizontalService,
	                  private _router: Router){
        console.log('HorizontalMenuComponent load');
    }
	getMenuLabel()
	{
       this.horizontal={};
	   this._horizontalService.gethorizontallabel()
	   .subscribe(horizon => {
					console.log('from horizontla menu: '+horizon);
					this.assignresponses(horizon);
			});

			
	}

	assignresponses(rest:any)
	{
	
	this.horizontal.DashBoard=rest.FieldName1;
	this.horizontal.VehicleList=rest.FieldName2;
	this.horizontal.Address=rest.FieldName3;
	this.horizontal.SignOut=rest.FieldName4;
	this.horizontal.Customers=rest.FieldName5;
	this.horizontal.MakePayment=rest.FieldName6;
	this.horizontal.PaymentHistory="Payment History";
	this.horizontal.DriverList="DriverList";

	}
	 ngOnInit() {
        this.getMenuLabel();
		this.UserName= sessionStorage.getItem("userName");
    }
}