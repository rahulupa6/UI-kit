﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import { CONFIG } from 'common/config.ts'

let  HorizontalUrl=CONFIG.baseUrls.HorizontalsUrl;


 

export interface Horizontal
{
DashBoard:string;
VehicleList:string;
Address:string;
Customers:string;
MakePayment:string;
PaymentHistory:string;
DriverList:string;
SignOut:string;
}

@Injectable()
export class HorizontalService {
  constructor(private _http: Http
  ) {
      console.log('Header load');
  }

  gethorizontallabel() {
     
	  console.log('resss:'+HorizontalUrl);

    return this._http.get(HorizontalUrl)
      .map((response: Response) =><Horizontal>(response.json()))
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

 
}