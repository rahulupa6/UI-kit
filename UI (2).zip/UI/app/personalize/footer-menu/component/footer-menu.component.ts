import {Component, Injectable } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import {Footer,FooterService} from '../service/footer-menu.service'


@Component({
    selector: 'footermenu',
    templateUrl: 'app/personalize/footer-menu/view/footer-menu.component.html',
	 directives: [ROUTER_DIRECTIVES],
	 providers:[FooterService]
})



export class FooterComponent {
 /*  CopyRight:string="";
  FindAgent:string="";
  ContactUs:string="";
 CallUs:string="";
 ChatUs:string="";
 */
 footer:Footer;

   constructor(private _footerService: FooterService,
	                    private _router: Router) {
        console.log('FooterComponent load');
    }
	getLabel()
	{
       this.footer={};
	   this._footerService.getfooterlabel()
	   .subscribe(footer => {
	            this.assignResponse3(footer);  
			//this.footer=footer;
			});

			console.log(this.footer);
	}
	assignResponse3(ress:any)
	{
	console.log('res'+ress);
	this.footer.CopyRight=ress.FieldName1;
	this.footer.ContactUs=ress.FieldName2;
	this.footer.CallUs=ress.FieldName3;
	this.footer.ChatUs=ress.FieldName4;
	this.footer.FindAgent="Find Agent";
	}
	 ngOnInit() {
        this.getLabel();
    }
	

}