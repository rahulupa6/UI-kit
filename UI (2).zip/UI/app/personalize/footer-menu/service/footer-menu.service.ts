﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import { CONFIG } from 'common/config.ts'

let FooterUrl=CONFIG.baseUrls.FootersUrl;


 

export interface Footer
{
CopyRight:string;
FindAgent:string;
ContactUs:string;
CallUs:string;
ChatUs:string;
}

@Injectable()
export class FooterService {
  constructor(private _http: Http
  ) {
      console.log('Footer load');
  }

  getfooterlabel() {
      console.log(FooterUrl);

    return this._http.get(FooterUrl)
      .map((response: Response) => (response.json()))
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

 
}