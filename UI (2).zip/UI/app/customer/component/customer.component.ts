import{Component,OnDestroy, OnInit} from 'angular2/core';
import { ROUTER_DIRECTIVES,Router} from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';
import { Address,ICustomerDetails,CustomerService } from '../service/customer.service';
let backUrl = 'app/dashboard/view/dashboard.component.html';
@Component({

selector:'customer-details',
templateUrl:'app/customer/view/customer.component.html',
directives: [ ROUTER_DIRECTIVES],
 styleUrls: ['css/profileDetail.css'],
providers:[CustomerService]

})
export class CustomerComponent implements OnDestroy, OnInit{

customerLabels:ICustomerDetails;
customerData:ICustomerDetails;
address : string;
address1: string;

constructor(private _customerService: CustomerService,
				private _router: Router) {  
					
    }

	cancel(){
	this._router.navigate(['Shell']);
	}

	


	   ngOnDestroy() {
    }

    ngOnInit() {
					this.customerLabels={};
					this.customerData={};
					this.customerData.residentialAddress=[];

      this.getcustomerLabels();
		//this.enable(true);
		this.getcustomerData();
    }

 getcustomerData() {
        console.log("Calling the getPaymentLabel");
        //	this.paymentLabels= '';
		this._customerService.getCustomers()
					 .subscribe(
                       customerData =>

					   if(customerData != undefined)
					   {
						    this.customerData = customerData;
                            console.log("compo- "+this.customerData);
						    this.customerData.residentailAddress=customerData.residentialAddress;

							//let str=JSON.stringify(customerData);
							//this.customerData = JSON.parse(str);
							console.log(this.customerData.residentailAddress[0].city);
							//this.customerData.residentialAddress=obj;

						//	this.address=obj.residentailAddress[0].line1+","+obj.residentailAddress[0].line2+","+obj.residentailAddress[0].line3;
						//	this.address1=obj.residentailAddress[0].city+","+obj.residentailAddress[0].state+","+obj.residentailAddress[0].zipCode

							/*
							console.log(this.customerData.residentailAddress[0].line1);*/
						    
                       });
           
                   
    }
    getcustomerLabels() {
        console.log("Calling the getPaymentLabel");
        //	this.paymentLabels= '';
		this._customerService.getLabels()
					 .subscribe(
                       customerLabels =>{
						//   alert(customerLabels);
                            this.customerLabels = customerLabels;
                                       
                       });
           
                   
    }

}