﻿import { Injectable } from 'angular2/core';
import { Http, Response ,Headers} from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';


let customerLabel=CONFIG.baseUrls.customersUrl;
let customerData=CONFIG.baseUrls.customersDataUrl;
let customerPostData=CONFIG.baseUrls.customerPostUrl;

export interface ICustomerDetails {

  residentailAddress: Address[];
  phoneNumber:string;
  phoneNumber2:string
  middleName:string;
  firstName: string;
  lastName: string;

  
}

export interface Address 
{
	line1: string;
	line2 : string;
	line3 : string;
	city : string;
	state : string;
	country: string;
	zipCode : string;

}

@Injectable()
export class CustomerService {
  constructor(private _http: Http
  ) {
      console.log('customer load');
  }


  private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
  getLabels()
  {
     return this._http.get(customerLabel).map((response:Response)=>
      <ICustomerDetails>response.json().CustomerLabels)
      .do(CustomerLabels=>console.log(CustomerLabels))
      .catch(
        this.handleError)
    ;
  }
  getCustomers() 
  {
    /* return this._http.get(customerData).map((response:Response)=>
      <ICustomerDetails>response.json())
      .do(data=>console.log(data))
      .catch(
        this.handleError)
    ;*/

	/* let headers = new Headers();
         headers.append('Content-Type', 'application/json');   
		 headers.append('Access-Control-Allow-Origin', '*');   

		  

			let body = '{"userId":"'+sessionStorage.getItem("userId")+'"}';
			//let body = '{"userId":"VR5032386"}';
			console.log('body' + body);
					
	return this._http
            .post(customerPostData, body,{headers : headers})
			
            .map((response: Response) => <ICustomerDetails>response.json())
			.do(d=>console.log(JSON.stringify(d)))
            .catch(this.handleError)
            .finally();*/
			
			return this._http
            .get('api/CustomerPost.json')
            .map((response: Response) => response.json())
			.do(d=>console.log('d'+d))
            .catch(this.handleError)
            .finally();
  }


//   postCustomer(customer:ICustomer){
  //
//   console.log(customer);

//  /* this._http.post(customersUrl)
//   .map((request:Request)=>)*/
  
  
  
//   }

 
}