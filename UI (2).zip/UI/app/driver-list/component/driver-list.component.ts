﻿import { Component, OnDestroy, OnInit, ViewChild } from 'angular2/core';
import { ROUTER_DIRECTIVES,Router } from 'angular2/router';
import { Observable, Subscription } from 'rxjs/Rx';

import { Driver,DriverListService } from '../service/driver-list.service';

@Component({
    selector: 'driver-list',
    templateUrl: 'app/driver-list/view/driver-list.component.html',
    directives: [ ROUTER_DIRECTIVES],
	providers :[DriverListService]
})
export class DriverListComponent implements OnDestroy, OnInit {

   
	driverList:any[];
	
    constructor(private _driverListService: DriverListService,
				private _router: Router) {  
       /* this.drivers=[];  
        this.filteredDrivers1=[];
        this.filteredDrivers2=[];*/
          
}
    

	back(){
	this._router.navigate(['Home']);
	}
 
    getDrivers() {
      
		/*this._driverListService.getDrivers()
					.subscribe(drivers => {
								this.drivers = drivers;
                                var length=this.drivers.length;
                            
                                    for(let i =0;i<length;i++)
                                    {
                                        
                                        if(i<2)
                                        {
                                            this.filteredDrivers1[i]=this.drivers[i];
                                            if(i+2 < length)
                                            {
   
                                         this.filteredDrivers2[i]=this.drivers[i+2];    
                                            }
                                           
                                        }else
                                        {
                                            break;
                                        }
                                    
                                }
                                console.log( this.filteredDrivers1.length);
                                console.log( this.filteredDrivers2.length);
                                
					});*/

					let obj=JSON.parse(sessionStorage.getItem('PolicyDetails'));
					this.driverList=obj.drivers;
					console.log("driverList:",this.driverList);
    }
	add()
	{
	this._router.navigate(['Driver']);
	}
    ngOnDestroy() {
    }

    ngOnInit() {
        this.getDrivers();
    }
}
