﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import { CONFIG } from 'common/config.ts';

let driversUrl = CONFIG.baseUrls.driverListUrl;

export interface Driver {
  id: number;
  name: string;
  drivingLicenseNumber:string
}

@Injectable()
export class DriverListService {
  constructor(private _http: Http
  ) {
      console.log('drivers load');
  }

  getDrivers() {
      console.log(driversUrl);

    return this._http.get(driversUrl)
      .map((response: Response) => <Driver[]>response.json().data)
	   .do(data => console.log(data))
      .catch(this.handleError)
      
  }
 private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
 
 
}