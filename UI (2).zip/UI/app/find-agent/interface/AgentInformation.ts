
export interface AgentInformation
{
  name: string;
  address: string;
  latitude: string;
  longitude:string;
  
}



