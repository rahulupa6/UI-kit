
import { Injectable } from 'angular2/core';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';

export interface LatLng
   {
    lat: number;
    lng:number; 
   }
@Injectable()
export class GeoLocation {
      private map;
      private latling;
     private overlay;
  //    latLng:LatLng;
     private address;
    private  markers=[];
     pos;
     
     
     
     latLng: Observable<LatLng>; 
    private _baseUrl: string;
    private _latLngObserver: Observer<LatLng>;
    
      // agentInfo:AgentInformation[];
  constructor(
  ) 
  {
 this.latLng = new Observable(observer => this._latLngObserver = observer).share();
  }
   
    
   public initMap() {
     
        //  this.getCurrentLatLng();
          //console.log('init mP'+lt);
          this.latling = new google.maps.LatLng(18.5204, 73.8567);
            var myOptions = {
                zoom: 9,
                center: this.latling,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
       this. map = new google.maps.Map(document.getElementById('mapView'), myOptions);
         this.overlay = new google.maps.OverlayView();
            this.overlay.draw = function() {}; // empty function required
            this.overlay.setMap(this.map);
         
  
  }
     addMarker(x, y,name)
    {
        console.log("Inside the Marker");
            this.latling = new google.maps.LatLng(x, y);
            var marker = new google.maps.Marker({
            position: this.latling,
            map: this.map,
            title: name
          });
        
        marker.info = new google.maps.InfoWindow({
    content: name
        }   );
  marker.addListener('click', function() {
    this.map.setZoom(10);
    this.map.setCenter(marker.getPosition());
     marker.info.open(this.map, marker);
     });
         this.markers.push(marker);
    }

         //Delete all Markers
    deleteAllMarkers (){
    for (var marker of this.markers) {
            //Remove the marker from Map                  
                marker.setMap(null);
            }
            //Remove the marker from array.
            this.markers.length = 0;
    };
        

        
        
        
private getCurrentLatLng() : Observable<LatLng>
{
  
         this.latLng={};
        var infoWindow = new google.maps.InfoWindow({map: this.map});
        var pos
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
         pos = {
              lat : position.coords.latitude,
              lng: position.coords.longitude
            };
           
           this.latLng=pos;
            },
             function() {
           this.handleLocationError(true, infoWindow, this.map.getCenter());
           alert("Inside Error");
          });
        } else {
          // Browser doesn't support Geolocation
         this. handleLocationError(false, infoWindow, this.map.getCenter());
        } 
      return  this.latLng;     
}
data:LatLng;
getCurrentLocation()
{
  
   return this.getCurrentLatLng().map((latLng)=>this.data=latLng);
}
     handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
      }
       
}