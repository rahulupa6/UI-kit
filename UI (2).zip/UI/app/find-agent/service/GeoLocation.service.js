System.register(['angular2/core', 'rxjs/Observable'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, Observable_1;
    var GeoLocation;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            }],
        execute: function() {
            GeoLocation = (function () {
                // agentInfo:AgentInformation[];
                function GeoLocation() {
                    var _this = this;
                    this.markers = [];
                    this.latLng = new Observable_1.Observable(function (observer) { return _this._latLngObserver = observer; }).share();
                }
                GeoLocation.prototype.initMap = function () {
                    //  this.getCurrentLatLng();
                    //console.log('init mP'+lt);
                    this.latling = new google.maps.LatLng(18.5204, 73.8567);
                    var myOptions = {
                        zoom: 9,
                        center: this.latling,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    };
                    this.map = new google.maps.Map(document.getElementById('mapView'), myOptions);
                    this.overlay = new google.maps.OverlayView();
                    this.overlay.draw = function () { }; // empty function required
                    this.overlay.setMap(this.map);
                };
                GeoLocation.prototype.addMarker = function (x, y, name) {
                    console.log("Inside the Marker");
                    this.latling = new google.maps.LatLng(x, y);
                    var marker = new google.maps.Marker({
                        position: this.latling,
                        map: this.map,
                        title: name
                    });
                    marker.info = new google.maps.InfoWindow({
                        content: name
                    });
                    marker.addListener('click', function () {
                        this.map.setZoom(10);
                        this.map.setCenter(marker.getPosition());
                        marker.info.open(this.map, marker);
                    });
                    this.markers.push(marker);
                };
                //Delete all Markers
                GeoLocation.prototype.deleteAllMarkers = function () {
                    for (var _i = 0, _a = this.markers; _i < _a.length; _i++) {
                        var marker = _a[_i];
                        //Remove the marker from Map                  
                        marker.setMap(null);
                    }
                    //Remove the marker from array.
                    this.markers.length = 0;
                };
                ;
                GeoLocation.prototype.getCurrentLatLng = function () {
                    this.latLng = {};
                    var infoWindow = new google.maps.InfoWindow({ map: this.map });
                    var pos;
                    // Try HTML5 geolocation.
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function (position) {
                            pos = {
                                lat: position.coords.latitude,
                                lng: position.coords.longitude
                            };
                            this.latLng = pos;
                        }, function () {
                            this.handleLocationError(true, infoWindow, this.map.getCenter());
                            alert("Inside Error");
                        });
                    }
                    else {
                        // Browser doesn't support Geolocation
                        this.handleLocationError(false, infoWindow, this.map.getCenter());
                    }
                    return this.latLng;
                };
                GeoLocation.prototype.getCurrentLocation = function () {
                    var _this = this;
                    return this.getCurrentLatLng().map(function (latLng) { return _this.data = latLng; });
                };
                GeoLocation.prototype.handleLocationError = function (browserHasGeolocation, infoWindow, pos) {
                    infoWindow.setPosition(pos);
                    infoWindow.setContent(browserHasGeolocation ?
                        'Error: The Geolocation service failed.' :
                        'Error: Your browser doesn\'t support geolocation.');
                };
                GeoLocation = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], GeoLocation);
                return GeoLocation;
            }());
            exports_1("GeoLocation", GeoLocation);
        }
    }
});
//# sourceMappingURL=GeoLocation.service.js.map