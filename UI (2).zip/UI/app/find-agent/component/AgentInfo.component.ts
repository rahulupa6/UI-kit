import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';

import {AgentInformation} from '../interface/AgentInformation';
import {AgentInfo,AgentsService } from '../service/Agents.service';

@Component({
    selector: 'agent-info',
   templateUrl: 'app/find-agent/view/agentDetail.component.html',
    directives: [ROUTER_DIRECTIVES],
   
    providers: [
    ]
})



export class AgentInfoComponent implements OnDestroy, OnInit {
  agentInfo:AgentInfo;
  visible:boolean = false;
agentInformation:AgentInformation[];
 showAgent(agentInformation) {
     console.log("Show agents")
      this.agentInformation=agentInformation;
        this.visible = !this.visible;
    
  }
    constructor(private _router: Router,
				private _agentService:AgentsService) {  
    }

	back(){
	this._router.navigate(['Home']);
	}
 
  getAgentInfoLabel()
  {
    this._agentService.getAgentInfoLabels()
            .subscribe(agentsinfo => {

			this.assignAgentInfoLabel(agentsinfo)
                //this.userLogin.Login = logins;
               
            });
  }

  assignAgentInfoLabel(ageinf:any)
  {
  this.agentInfo={};
    this.agentInfo.Name=ageinf.FieldName1;
    //console.log('ans:'+res.ButtonName);
	this.agentInfo.Address=ageinf.FieldName2;
	this.agentInfo.Mobile=ageinf.FieldName3;
  }
    ngOnDestroy() {
    }

    ngOnInit() {
       this.visible  =false; 
	   this.getAgentInfoLabel();   
    }
     
}