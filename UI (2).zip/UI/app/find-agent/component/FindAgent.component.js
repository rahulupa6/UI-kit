System.register(['angular2/core', 'angular2/router', '../service/Agents.service', '../component/AgentInfo.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, Agents_service_1, AgentInfo_component_1;
    var FindAgentComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (Agents_service_1_1) {
                Agents_service_1 = Agents_service_1_1;
            },
            function (AgentInfo_component_1_1) {
                AgentInfo_component_1 = AgentInfo_component_1_1;
            }],
        execute: function() {
            FindAgentComponent = (function () {
                function FindAgentComponent(_agentService, _router) {
                    this._agentService = _agentService;
                    this._router = _router;
                    this.markers = [];
                    this.labelIndex = 0;
                    this.lat = 0;
                }
                FindAgentComponent.prototype.back = function () {
                    this._router.navigate(['Home']);
                };
                FindAgentComponent.prototype.ngOnDestroy = function () {
                };
                FindAgentComponent.prototype.ngOnInit = function () {
                    this.initMap();
                    this.getCurrentLatLng();
                    // setTimeout(this.getAge,1000);  
                };
                FindAgentComponent.prototype.initMap = function () {
                    this.latling = new google.maps.LatLng(18.5204, 73.8567);
                    var myOptions = {
                        zoom: 9,
                        center: this.latling,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    };
                    this.map = new google.maps.Map(document.getElementById('mapView'), myOptions);
                    this.overlay = new google.maps.OverlayView();
                    this.overlay.draw = function () { }; // empty function required
                    this.overlay.setMap(this.map);
                };
                FindAgentComponent.prototype.addMarker = function (x, y, name) {
                    console.log("Inside the Marker");
                    this.latling = new google.maps.LatLng(x, y);
                    var marker = new google.maps.Marker({
                        position: this.latling,
                        map: this.map,
                        title: name
                    });
                    marker.info = new google.maps.InfoWindow({
                        content: name
                    });
                    marker.addListener('click', function () {
                        this.map.setZoom(10);
                        this.map.setCenter(marker.getPosition());
                        marker.info.open(this.map, marker);
                        alert(marker.getTitle());
                    });
                    this.markers.push(marker);
                };
                //Delete all Markers
                FindAgentComponent.prototype.deleteAllMarkers = function () {
                    for (var _i = 0, _a = this.markers; _i < _a.length; _i++) {
                        var marker = _a[_i];
                        //Remove the marker from Map                  
                        marker.setMap(null);
                    }
                    //Remove the marker from array.
                    this.markers.length = 0;
                };
                ;
                FindAgentComponent.prototype.findAgent = function () {
                    // this.getAgents(this.latLng);
                    // this.addMarker(18.5204, 73.8567);
                };
                FindAgentComponent.prototype.getCurrentLatLng = function () {
                    console.log("inside getCurrent");
                    var infoWindow = new google.maps.InfoWindow({ map: this.map });
                    var pos;
                    // Try HTML5 geolocation.
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(this.getAgents.bind(this), function () {
                            this.handleLocationError(true, infoWindow, this.map.getCenter());
                            alert("Inside Error");
                        });
                    }
                    else {
                        // Browser doesn't support Geolocation
                        this.handleLocationError(false, infoWindow, this.map.getCenter());
                    }
                    //return  pos;     
                };
                FindAgentComponent.prototype.handleLocationError = function (browserHasGeolocation, infoWindow, pos) {
                    infoWindow.setPosition(pos);
                    infoWindow.setContent(browserHasGeolocation ?
                        'Error: The Geolocation service failed.' :
                        'Error: Your browser doesn\'t support geolocation.');
                };
                FindAgentComponent.prototype.getAgents = function (position) {
                    var _this = this;
                    console.log("Show agents");
                    var pos = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    console.log("Show agents - " + pos.lat);
                    this.lat = pos.lat;
                    this.lang = pos.lng;
                    this.agentInformation = [];
                    this._agentService.getNearbyAgents(pos).subscribe(function (agentsDeatail) {
                        _this.agentInformation = agentsDeatail;
                        for (var _i = 0, _a = _this.agentInformation; _i < _a.length; _i++) {
                            var agentInfo = _a[_i];
                            _this.addMarker(agentInfo.latitude, agentInfo.longitude, agentInfo.name);
                        }
                        console.log("end Show agents");
                        console.log("Agents" + _this.agentInformation);
                        _this.agentInfoComponent.showAgent(_this.agentInformation);
                        //this.getAge(pos);
                        ///console.log("Show agents"+ this.pos.lng)
                    });
                };
                FindAgentComponent.prototype.getAge = function (pos) {
                    console.log("Show" + this.lat);
                    //console.log(this.pos);
                    /*this.agentInformation= [];
                   this._agentService.getNearbyAgents(pos).subscribe(agentsDeatail =>{
                  
                   this.agentInformation=agentsDeatail
                       for (var agentInfo of this.agentInformation) {
                        
                           this.addMarker( agentInfo.latitude,agentInfo.longitude,agentInfo.name)
                   }
                     console.log("Show agents")
                     console.log("Agents"+this.agentInformation)
               this.agentInfoComponent.showAgent(this.agentInformation);
               })*/
                };
                __decorate([
                    core_1.ViewChild(AgentInfo_component_1.AgentInfoComponent), 
                    __metadata('design:type', AgentInfo_component_1.AgentInfoComponent)
                ], FindAgentComponent.prototype, "agentInfoComponent", void 0);
                FindAgentComponent = __decorate([
                    core_1.Component({
                        selector: 'view-transactionst',
                        //template:`<H1>Hi SHubham Jain</H1>`,
                        templateUrl: 'app/find-agent/view/find-agent.component.html',
                        directives: [router_1.ROUTER_DIRECTIVES, AgentInfo_component_1.AgentInfoComponent],
                        styles: ["\n    #mapView {\n      height: 1000px;\n      width: 1000px;\n     border:solid\n    }\n  "],
                        providers: [
                            Agents_service_1.AgentsService
                        ]
                    }), 
                    __metadata('design:paramtypes', [Agents_service_1.AgentsService, router_1.Router])
                ], FindAgentComponent);
                return FindAgentComponent;
            }());
            exports_1("FindAgentComponent", FindAgentComponent);
        }
    }
});
//# sourceMappingURL=FindAgent.component.js.map