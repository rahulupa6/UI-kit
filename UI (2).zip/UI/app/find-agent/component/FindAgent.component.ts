import {Component, Injectable , OnDestroy, OnInit, ViewChild } from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, Router } from 'angular2/router';
import {AgentLabel,AgentsService } from '../service/Agents.service';
import {AgentInformation} from '../interface/AgentInformation';
import {AgentInfoComponent} from '../component/AgentInfo.component';
@Component({
    selector: 'view-transactionst',
   templateUrl: 'app/find-agent/view/find-agent.component.html',
    directives: [ROUTER_DIRECTIVES,AgentInfoComponent],
     styles: [`
    #mapView {
      height: 1000px;
      width: 1000px;
     border:solid
    }
  `],
    providers: [
       AgentsService
    ]
})



export class FindAgentComponent implements OnDestroy, OnInit {

agent:AgentLabel;

lat:number;
lang:number;
Agent:this;

 @ViewChild(AgentInfoComponent) agentInfoComponent:AgentInfoComponent;
agentInformation:AgentInformation[];
    constructor(private _agentService:AgentsService,
				private _router: Router) {  
            this.lat=0;
    }

	back(){
	this._router.navigate(['Home']);
	}
 
  
    ngOnDestroy() {
    }

    ngOnInit() {
	this.agent={};
	this.getAgentLabel();

       this.initMap();
		this.getCurrentLatLng();
     // setTimeout(this.getAge,1000);  
      
    }

      zipCode;  
	  map;
      latling;
     overlay;
     address;
     latLng;
     markers=[];
     labelIndex=0;
     initMap() {
         
          this.latling = new google.maps.LatLng(18.5204, 73.8567);
            var myOptions = {
                zoom: 9,
                center: this.latling,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
       this.map = new google.maps.Map(document.getElementById('mapView'), myOptions);
         this.overlay = new google.maps.OverlayView();
            this.overlay.draw = function() {}; // empty function required
            this.overlay.setMap(this.map);
  
}

    addMarker(x, y,name)
    {
        console.log("Inside the Marker");
            this.latling = new google.maps.LatLng(x, y);
            var marker = new google.maps.Marker({
            position: this.latling,
            map: this.map,
           
             title: name
          });
        
        marker.info = new google.maps.InfoWindow({
    content: name
        }   );
  marker.addListener('click', function() {
    this.map.setZoom(10);
    this.map.setCenter(marker.getPosition());
     marker.info.open(this.map, marker);
       //alert( marker.getTitle());
  });
         this.markers.push(marker);
    }

         //Delete all Markers
        deleteAllMarkers (){
        
         for (var marker of this.markers) {

                //Remove the marker from Map                  
                marker.setMap(null);
            }

            //Remove the marker from array.
            this.markers.length = 0;
           

              
        };


getAgentLabel()
{
  console.log('Agent label hit');
    this._agentService.getAgentLabels()
            .subscribe(agents => {
			 if(agents != undefined)
			 {
				console.log(agents);
				this.assignAgentLabel(agents)
                //this.userLogin.Login = logins;
              } 
            });
}

assignAgentLabel(age:any)
{
	this.agent.EnterZipCode=age.FieldName1;
    //console.log('ans:'+res.ButtonName);
	this.agent.LocateAgent=age.FieldName2;
	
	
}


findAgent()
{
       
  
  // this.getAgents(this.latLng);

  
   
   // this.addMarker(18.5204, 73.8567);
}


public getCurrentLatLng() 
{
   console.log("inside getCurrent")
       
        var infoWindow = new google.maps.InfoWindow({map: this.map});
        var pos
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(this.getAgents.bind(this),
             function() {
           this.handleLocationError(true, infoWindow, this.map.getCenter());
           alert("Inside Error");
          });
           
        } else {
          // Browser doesn't support Geolocation
         this.handleLocationError(false, infoWindow, this.map.getCenter());
        } 
        
      //return  pos;     
}
  handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
      }

getAgents(position)
{ 
      console.log("Show agents")
  var pos = {
        lat : position.coords.latitude,
              lng: position.coords.longitude
           };
           console.log("Show agents - "+ pos.lat)

    this.lat=pos.lat;
    this.lang=pos.lng;        
    
    this.agentInformation= [];
    this._agentService.getNearbyAgents(pos).subscribe(agentsDeatail =>{
   
    this.agentInformation=agentsDeatail
        for (var agentInfo of this.agentInformation) {
         
            this.addMarker( agentInfo.latitude,agentInfo.longitude,agentInfo.name)
    }
      console.log("end Show agents")
      console.log("Agents"+this.agentInformation)
this.agentInfoComponent.showAgent(this.agentInformation);
 //this.getAge(pos);
    
///console.log("Show agents"+ this.pos.lng)
})
}
getAge(pos)
{
  console.log("Show"+this.lat)
  //console.log(this.pos);
     /*this.agentInformation= [];
    this._agentService.getNearbyAgents(pos).subscribe(agentsDeatail =>{
   
    this.agentInformation=agentsDeatail
        for (var agentInfo of this.agentInformation) {
         
            this.addMarker( agentInfo.latitude,agentInfo.longitude,agentInfo.name)
    }
      console.log("Show agents")
      console.log("Agents"+this.agentInformation)
this.agentInfoComponent.showAgent(this.agentInformation);
})*/
     
}
} 