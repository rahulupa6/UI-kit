import {Component } from 'angular2/core';

import {  ROUTER_DIRECTIVES, ROUTER_PROVIDERS, RouteConfig } from 'angular2/router';

import {HomeComponent} from 'app/home/component/home.component';
import {VehicleListComponent} from 'app/vehicle-list/component/vehicle-list.component';

import {HorizontalMenuComponent} from 'app/personalize/horizontal-menu/component/horizontal-menu.component';
import {FooterComponent} from 'app/personalize/footer-menu/component/footer-menu.component';
import{CustomerComponent} from 'app/customer/component/customer.component';

import {MakePaymentComponent} from 'app/make-payment/payment/component/payment.component';
import {ViewTransactionComponent} from 'app/history/component/TransactionHistory.component';
import {AddressComponent} from 'app/address/component/address.component';
import {VehicleComponent} from 'app/vehicle-detail/component/vehicle-detail.component';

import{DriverDataComponent} from 'app/driver/component/driver.component';
import{DriverListComponent} from 'app/driver-list/component/driver-list.component';

import{PolicyComponent} from 'app/policy/component/policy.component';
import{PolicyDetailsComponent} from 'app/policy-details/component/policy-details.component';
//import {DashBoard,DashBoardService} from 'app/dashboard/service/dashboard.service';

import{NomineeComponent} from 'app/nominee/component/nominee.component';
import {FindAgentComponent} from 'app/find-agent/component/FindAgent.component';
import{ChatUsComponent} from 'app/chat-us/component/chat-us.component';
import {ProfDetailsComponent} from 'app/prof-detail/component/prof-detail.component';
import {PaymentListComponent} from 'app/payment-list/component/payment-list.component';
import {NewOffersComponent} from 'app/new-offers/component/new-offers.component';
import { ToastComponent, ToastService } from 'app/blocks/blocks';

@Component({
    selector: 'dashboard',
    templateUrl: 'app/dashboard/view/dashboard.component.html',
    directives: [ROUTER_DIRECTIVES, HorizontalMenuComponent, FooterComponent,ToastComponent],
    providers: [
        ToastService
    ]

})

@RouteConfig([{ path: '/Home', component: HomeComponent, name: 'Shell', useAsDefault: true}},
 { path: '/Vehicle-list', component: VehicleListComponent, name: 'Vehicles' },
 { path: '/vehicle-detail/:id', component: VehicleComponent, name: 'Vehicle_Detail' },
 { path: '/Customer', component: CustomerComponent, name: 'Customers' },
 { path: '/transactionHistory', component: ViewTransactionComponent, name: 'TransactionHistory'},
 { path: '/makePayment', component: MakePaymentComponent, name: 'MakePayment' },
 { path: '/address', component:AddressComponent, name: 'Address' },
 { path: '/Driver', component: DriverDataComponent, name: 'Driver' },
{ path: '/DriverList', component: DriverListComponent, name: 'DriverList' },
{ path: '/Policy', component: PolicyComponent, name: 'Policy' },
{ path: '/PolicyList', component: PolicyDetailsComponent, name: 'PolicyList'},
{ path: '/Nominee', component: NomineeComponent, name: 'Nominee' },
 { path: '/findAgent', component: FindAgentComponent, name: 'FindAgent'},
 { path: '/ChatUs', component: ChatUsComponent, name: 'ChatUs' },
 {path:'/prof-detail',component:ProfDetailsComponent,name:'ProfileDetails'},
 { path: '/payment-list', component: PaymentListComponent, name: 'Payments' },
 { path: '/new-offers', component: NewOffersComponent, name: 'NewOffers' }
 ]
)


export class Dashboard {
 // dashboard:DashBoard;

    constructor(  ) {
		console.log("dashboard")        
    }

	
	}