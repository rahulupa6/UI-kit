﻿import { Injectable } from 'angular2/core';
import { Http, Response } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

import { CONFIG } from 'common/config.ts';


let DashBoardUrl=CONFIG.baseUrls.MenusUrl;



 

export interface DashBoard
{
MyPolicies:string;
BillsPayments:string;
Claims:string;
TransactionHistory:string;
Documents:string;
NewOffers:string;
Search:string;
ImgIcon:string;
}

@Injectable()
export class DashBoardService {
  constructor(private _http: Http
  ) {
      console.log('DashBoard load');
  }

  getDashBoardlabel() {
      console.log(DashBoardUrl);

    return this._http.get(DashBoardUrl)
      .map((response: Response) => (response.json()))
	   .do(data => console.log(data))
      .catch(this.handleError)
      .finally();
  }

 
}